<?php

Route::get('/', 'HomeController@index')->name('home');

Auth::routes();

Route::post('/mergeFriends', 'UserController@mergeFriends');

Route::post('/MutualFriends/', 'UserController@MutualFriends');

Route::post('/getUser', 'UserController@getUser');

Route::post('/MyFriend', 'UserController@MyFriend');

Route::post('/get_Notification', 'UserController@get_Notification');

Route::post('/suggestionFriend', 'UserController@suggestionFriend');

Route::post('/checkAlreadyfriend', 'UserController@checkAlreadyfriend');

Route::post('/home_side_chat_list', 'UserController@home_side_chat_list');

Route::post('/get_search_friends', 'UserController@get_search_friends');

Route::post('/getAllPost', 'PostController@getAllPost');

Route::get('/post/{id}', 'PostController@getPostById')->name('post_by_id');

Route::get('/post/{id}/edit', 'PostController@edit')->middleware('auth');

Route::get('/getPostByFriends', 'PostController@getPostByFriends');

Route::post('/getPostByUser', 'PostController@getPostByUser');

Route::post('/getPostOfMy', 'PostController@getPostOfMy');

Route::post('/getPostByFriends', 'PostController@getPostByFriends');


Route::post('/update_post', 'PostController@update');



Route::post('/user_select_to_chat', 'UserConversationController@user_select_to_chat');

Route::post('/SaveNewLike', 'PostLikeController@SaveNewLike');



Route::post('/user_select_to_chat', 'UserConversationController@user_select_to_chat');

Route::post('/gotoMessenger', 'UserConversationController@gotoMessenger');



Route::post('/user_select_search_result', 'UserConversationController@user_select_search_result');

Route::post('/header_Conversation_list_with_one_messages', 'UserConversationController@header_Conversation_list_with_one_messages');

Route::post('/get_chat_messages', 'UserChatMessagesController@show');


Route::post('/save_new_chat_messages', 'UserChatMessagesController@store');





Route::post('/createPost', 'PostController@store');

Route::post('/createPostImage', 'PostController@storeimages');

Route::post('/deletePost', 'PostController@destroy');

Route::get('/messenger', 'UserChatMessagesController@index');

Route::post('/sendFriendRequest', 'FriendRequestController@sendFriendRequest');

Route::post('/cancel-request', 'FriendRequestController@cancel_request');

Route::post('/AcceptFriendRequestUrl', 'FriendRequestController@AcceptFriendRequest');

Route::post('/checkAlreadySendRequest', 'FriendRequestController@checkAlreadySendRequestController');

Route::get('/{username}/notifications', 'NotificationController@gettopage');

Route::post('/Authuserallnotification', 'NotificationController@Authuserallnotification');

Route::post('/markallasreadnotification', 'NotificationController@markallasreadnotification');

Route::post('/markasread', 'NotificationController@markasread');

Route::post('/deleteallnotification', 'NotificationController@deleteallnotification');

Route::post('/deletenotification', 'NotificationController@deletenotification');

Route::get('/{username}', 'UserProfileController@username');

Route::get('/{username}/profile-edit', 'UserProfileController@edit')->middleware('auth');

//comment save
Route::post('/savecomment','UserPostCommentController@store');


//search results
Route::post('/header_search','SearchController@search');

Route::get('/all-result/{text}/{id}','SearchController@allresultofsearch');


//edit profile
Route::post('/{username}/account_section_edit','UserProfileController@update')->middleware('auth');




