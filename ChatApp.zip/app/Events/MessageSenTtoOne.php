<?php

namespace App\Events;

use App\User;
use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Support\Facades\Auth;

class MessageSenTtoOne implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    private $result;
    private $user;
    private $c_id;
    public function __construct($result,$c_id)
    {
        $user = Auth::user();
        $this->user = $user;
        $this->result = $result;
        $this->c_id = $c_id;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('private.message.conversation.'.$this->result['new_message_saved']['m_to_user']);
    }
//    public function broadcastAs()
//    {
//        return 'App\Events\MessageSendTOConversation';
//    }
    public function broadcastWith()
    {
        return [$this->result,$this->c_id];
    }
}
