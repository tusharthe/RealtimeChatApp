<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Validator;
use Illuminate\Support\Facades\DB;
use App\User;
class UserProfile extends Model
{

    protected $fillable = [
        'user_id','about', 'mood_emoji', 'phone_number_2' ,'website', 'phone_number_1','current_city', 'other_info' , 'country', 'state' ,'hometown_city', 'mood_string', 'gender', 'relationship', 'religious_views', 'languages', 'date_of_birth', 'nickname' ,'work' ,'school' ,'profile_pic'
    ];
    public $timestamps = false;

    public function user()
    {
        return $this->belongsTo('App\User');

    }

    public function account_section_1($request)
    {
        $id = Auth::id();
        $user = User::where('email',$request->email)->first();
        if(Auth::user()->email === $request->email OR $user === null){
            DB::table('users')->where('id',$id)->update(['name'=>$request->name,'email'=>$request->email,'updated_at'=>NOW()]);
            DB::table('user_profiles')->where('user_id',$id)->update(['date_of_birth'=>$request->dateofbirth]);
            return 'Successfully Updated';
        }else {
            return 'E-mail is already taken';
        }

    }
    public function account_section_2($request)
    {

        if(Hash::check($request->old_password, Auth::user()->password)){

            $change = $request->user()->fill([
                'password' => Hash::make($request->password)
            ])->save();
            if($change){
                $mess = 'Password Was Successfully Change';
            }
        }
        else
            $mess  = 'Old Password Doesn\'t match';
        return $mess;
    }
    public function account_section_3($request)
    {
        $id = Auth::id();
        $result =
            DB::table('user_profiles')->where('user_id',$id)->update([
                'nickname'=>$request->nick_name,
                'about'=>$request->about,
                'hometown'=>$request->hometown,
                'country'=>$request->country,
                'state'=>$request->state,
                'phone_number_1'=>$request->phone_number_1,
                'phone_number_2'=>$request->phone_number_2,
                'website'=>$request->website,


            ]);


            DB::table('users')->where('id',$id)->update(['updated_at'=>NOW()]);
            return 'Successfully Updated';

    }

    public function account_section_4($request) {
        $image_path =   env('APP_URL').'photos/user_profile/'.$this->image_upload($request);
        $user = User::where('id',Auth::id())->update(['profile_pic'=>$image_path]);
       return 'successfully Updated';
    }

    public function image_upload($request) {
        define('UPLOAD_DIR',"photos/user_profile/");
        $image_parts = explode(";base64,", $request->image_bse64);

        $image_type_aux = explode("image/", $image_parts[0]);

        $image_type = $image_type_aux[1];




        $name = 'pic_'.uniqid().md5(rand(2,45) . microtime());
        $fileName = $name.'.'.$image_type;

        $image_base64 = base64_decode($image_parts[1]);

        $file = UPLOAD_DIR . $fileName;
        file_put_contents($file, $image_base64);

        return $fileName;


    }
}
