<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserConversation extends Model
{
    protected $fillable = [
        'status','from_user','to_user','deleted_at'
    ];

    public function scopeGet_user_conversation_list()
    {

        $id = Auth::user()->id;
        $user = "SELECT conversation.`id` as c_id, conversation.`status` as c_status, conversation.`updated_at` as c_created_at, user.`id` as u_id, user.`name` as u_name, user.`username` as u_username, user.`email` as u_email, user.`profile_pic` as u_profile_pic FROM sns_user_conversations as conversation INNER JOIN sns_users as user WHERE (conversation.from_user = $id OR conversation.to_user = $id) AND ((user.id = conversation.from_user or user.id = conversation.to_user) AND user.id != $id) ORDER BY conversation.updated_at DESC";
         $db = DB::select($user);
        return $db;
    }

    public function scopeHeader_Conversation_list_with_one_messages()
    {

        $id = Auth::user()->id;
        $user = "SELECT conversation.`id` as c_id, conversation.`status` as c_status, conversation.`updated_at` as c_created_at, user.`id` as u_id, user.`name` as u_name, user.`username` as u_username, user.`email` as u_email, user.`profile_pic` as u_profile_pic FROM sns_user_conversations as conversation INNER JOIN sns_users as user WHERE (conversation.from_user = $id OR conversation.to_user = $id) AND ((user.id = conversation.from_user or user.id = conversation.to_user) AND user.id != $id) ORDER BY conversation.updated_at DESC LIMIT 6";
        $db = DB::select($user);$conver = [];
        foreach ($db as $key=>$v){
            $query = "SELECT message.id as m_id, message.status as m_status , message.from_user as m_from_user, message.to_user as m_to_user ,message.body as m_body, message.deleted_at as m_deleted_at, message.created_at as m_created_at FROM sns_user_conversations as conversation INNER JOIN sns_user_chat_messages as message where (conversation.id = message.user_conversation_id AND conversation.id = $v->c_id) order by message.created_at DESC LIMIT 1";
            $mess= DB::select($query);
            $v->message1 = $mess;
            $conver[] = $v;
        }
        return $conver;
    }
}
