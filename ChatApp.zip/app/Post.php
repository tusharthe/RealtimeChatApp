<?php

namespace App;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Auth;
use DB;


class Post extends Model
{
    use Notifiable;

    protected $fillable = [
        'user_id','body','title','slug','image'
    ];
    public function likes(){
        return $this->hasMany(PostLike::class,'post_id');
    }

    public function comments(){
        return $this->hasMany(UserPostComment::class,'post_id');
    }

    public function user(){
        return $this->belongsTo('App\User');
    }
    public function followers()
    {
        return $this->hasMany('Follower', 'follower_id', 'id');
    }

    public function following()
    {
        return $this->hasMany('Follower', 'following_id', 'id');
    }


    public function AllUserPost($request){
        $post = Post::with('user','likes','comments')->orderBy('updated_at','DESC')->limit('5')->offset($request->offset)->get();
        return $post;
    }

    public function getPostByUser($request){
        $offset = $request->offset;
        $post = User::where('username',$request->username)
            ->with(['post' => function($query) use ($offset){
                $query = $query->with(['likes','comments'=>function($q){$q->with('user')->get();}])->limit('3')->offset($offset)->orderBy('updated_at','DESC');
                return $query;
            }])
            ->first();
        return $post;
    }

    public function getPostOfMy($request){
        $post[] = Post::with('user','likes','comments')->where('user_id','=',Auth::user()->id)->orderBy('updated_at','DESC')->limit('5')->offset($request->offset)->get();
        return $post;
    }

    public function getPostByFriends($request)
    {

        if(Auth::check()){

            //             $user = Auth::user()->Friends();
            $auth_id  = Auth::user()->id;
            $user = Auth::user()->MyFriends()->get()->toArray();
            $user_id[] = $auth_id;
            foreach ($user as $userID) {
                $user_id[] = $userID['id'];
            }

            $user_post[] = Post::with(['user','likes','comments'=>function($q){
                $q->with('user')->orderBy('created_at', 'DESC')->limit('5')->get();
            }])->whereIn('user_id',  $user_id)->orderBy('updated_at', 'DESC')->limit('5')->offset($request->offset)->get()->toArray();

             return $user_post;
        }
    }

    public function getPostById($id){
        $result = Post::with(['user','likes','comments'=>function($qq){$qq->with('user')->orderBy('created_at', 'ASC')->get();}])->where('id',$id)->get();
        if($result)
            return $result;
        else
            return 'not found';
    }

    public function update_post($request){
        $body_array = preg_split("/\s+/", $request->post_text);

        foreach($body_array as $key => $value) {
            if(strpos($value, "www.youtube.com/watch?v=") !== false) {
                $link = preg_split("!&!", $value);
                parse_str( parse_url( $link[0], PHP_URL_QUERY ), $my_array_of_vars );
                $id_url[] =  $my_array_of_vars['v'];
                $body_array[$key] = '';
            }
        }
        $body_content = implode(" ", $body_array);
        if(!isset($id_url)){ $id_url = null;}

        $result =
            DB::table('posts')
            ->where('id', $request->id)
            ->where('user_id', $request->auth_id)
            ->update([
                'content' => $request->post_text,
                'updated_at' => NOW(),
                'youtube_link' => json_encode($id_url),
            ]);
        if($result)
            return 'success' ;
        else
            return 'error';
    }


    public function savenewpost($request){
        $body_array = preg_split("/\s+/", $request->postTextarea);

        foreach($body_array as $key => $value) {
            if(strpos($value, "www.youtube.com/watch?v=") !== false) {
                $link = preg_split("!&!", $value);
                parse_str( parse_url( $link[0], PHP_URL_QUERY ), $my_array_of_vars );
                $id_url[] =  $my_array_of_vars['v'];
                $body_array[$key] = '';
            }
        }
        if(!isset($id_url)){ $id_url = null;}

        $this->user_id = Auth::user()->id;
        $this->content = $request->postTextarea;
        $this->youtube_link = json_encode($id_url);
        $this->created_at = Now();
        $this->updated_at = Now();
        return $Post = $this->save();
        //                $friends = Auth::user()->Friends();
//                foreach ($friends as $friend ){
//                    User::find($friend->id)->notify(new NewPostSubmitNotification(Auth::user()));
//                }


    }

    public function savenewpostwithimage($request,$fileName){
        $this->user_id = Auth::user()->id;
        $this->content = $request->postTextarea;
        $this->images = $fileName;
        $this->created_at = Now();
        $this->updated_at = Now();
        return $Post = $this->save();
    }
}
