<?php

namespace App\Http\Controllers;
use App\User;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SearchController extends Controller
{
    public function search(Request $request)
    {
        if($request->ajax())
        {
            $q = $request->search_input_ajax;
            $user = User::where('name','LIKE','%'.$q.'%')->orWhere('email','LIKE','%'.$q.'%')->limit(6)->get();
            if(count($user) > 0)
            {
                return Response($user);
            }

        }
    }

    public function allresultofsearch(Request $request)
    {
        $users = User::where('name','LIKE','%'.$request->text.'%')->orWhere('email','LIKE','%'.$request->text.'%')->get();
        foreach($users as $user) {

            $result = $this->MutualFriends($user->id);
            $result = count($result);
            $user['count_mutual_friend'] = $result;
        }
        return view('searchresult.searchresult',compact('users'));
    }

    public function MutualFriends($id)
    {
        $user = [];
        $user1 =   User::find($id)->friendOf()->get();
        $user2 =   User::find($id)->MyFriends()->get();
        $users_1 =  $user2->merge($user1);

        $user1 =   User::find(Auth::user()->id)->friendOf()->get();
        $user2 =   User::find(Auth::user()->id)->MyFriends()->get();
        $users_2 =  $user2->merge($user1);


        foreach($users_1 as $users__1) {
            foreach($users_2 as $users__2) {
                if($users__1->id == $users__2->id ) {
                    $user[] =  $users__2;
                }
            }
        }
        return $user;
    }



}
