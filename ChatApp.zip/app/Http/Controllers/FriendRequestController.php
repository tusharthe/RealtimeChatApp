<?php

namespace App\Http\Controllers;

use App\FriendRequest;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Notifications\FriendRequestSendNotification;
use App\Notifications\FriendRequestAcceptNotification;

class FriendRequestController extends Controller
{

    public function AcceptFriendRequest(Request $request){
        $query =   DB::table('friend_requests')
            ->where('requester_user', '=',$request->to )
            ->where('requested_user', '=', Auth::user()->id )
            ->delete();
        if($query){
            Auth::user()->AddFriend($request->to);
            User::find($request->to)->notify(new FriendRequestAcceptNotification(Auth::user() ));
          //  $request->session()->put('accept_friend_request', Auth::user()->name.' accept your friend request');
        }
    }

        public function cancel_request(Request $request)
        {
            if($request->cancel_request){
              $query =   DB::table('friend_requests')
                    ->where('requester_user', '=', Auth::user()->id)
                    ->where('requested_user', '=', $request->to)
                    ->delete();
                if(!$query){
                    $query =   DB::table('friend_requests')
                        ->where('requester_user', '=',$request->to )
                        ->where('requested_user', '=', Auth::user()->id )
                        ->delete();
                }
                return $query;
            }

        }

    public function checkAlreadySendRequestController(Request $request){
            if($request->checkAlreadySendRequest) {
                $friend = new FriendRequest;

                $flights = $friend->checkAlreadySendRequest($request->to);

                if($flights){
                    return $flights;
                }
            }

        }

        public function sendFriendRequest(Request $request)
        {
           if($request->sendFriendRequest){
              //   DB::enableQueryLog();
               $friend = new FriendRequest;
               $friend = $friend->checkAlreadySendRequest($request->to);

               if( $friend != null){
                   return $friend;
               }

               $friend = new FriendRequest;
               $friend->requester_user = Auth::user()->id;

               $friend->requested_user = $request->to;

               $friend->status = 'pending';

               if($friend->save())
               {
                   User::find($request->to)->notify(new FriendRequestSendNotification(Auth::user() ));
//                   Session::flash('sendFriendRequestMassage', 'Friend Request has been send');
                   return 'true';
               }else{
                   return 'false';
               }


           }



               if($request->RemoveFriendRequest){
                   $user =  Auth::user()->UnFriend($request->to);
                   return $user;

               }





        }
}
