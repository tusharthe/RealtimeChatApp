<?php

namespace App\Http\Controllers;

use App\User;
use App\UserConversation;
use Illuminate\Support\Facades\Cache;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserConversationController extends Controller
{

    public function index()
    {
        //
    }


    public function create()
    {
        //
    }

    public function check_conversation_exit($request)
    {
        $userConversation =  UserConversation::where(function ($query) use($request){
            $query->where('from_user', Auth::user()->id)
                ->where('to_user', $request->selected_friend);
        })->
        orwhere(function ($query) use($request){
            $query->where('from_user', $request->selected_friend)
                ->where('to_user', Auth::user()->id );
        })->first();
        if($userConversation != null ) {return array('success_check' => true, 'conversation_id' => $userConversation->id); }

    }






    public function store(Request $request)
    {
        $result_check = $this->check_conversation_exit($request);
        if($result_check['success_check'] != true) {
            $userConversation = new UserConversation;
            $userConversation->from_user = Auth::user()->id;
            $userConversation->to_user = $request->selected_friend;
            $userConversation->save();
            return array('success' => true, 'conversation_id' => $userConversation->id);
        }
        return array('success' => true, 'conversation_id' => $result_check['conversation_id']);
    }


    public function show(UserConversation $userConversation)
    {
        //
    }


    public function edit(UserConversation $userConversation)
    {
        //
    }

    public function update(Request $request, UserConversation $userConversation)
    {

    }


    public function destroy(UserConversation $userConversation)
    {
        //
    }

    public function user_select_search_result(Request $request)
    {
        $result = $this->store($request);
        if($result['success'] === true){
            return $result;
        }

    }

    public function user_select_to_chat()
    {

        $users = UserConversation::Get_user_conversation_list();

            foreach ($users as $user) {
                if(Cache::has($this->getCacheKey($user->u_id)))
                 $user->is_Online = true;
                else
                 $user->is_Online = false;
            }
            return $users;

    }

    public function header_Conversation_list_with_one_messages()    {

        return $users = UserConversation::Header_Conversation_list_with_one_messages();

    }
    public function getCacheKey($user_id)
    {
        return sprintf('%s-%s', "UserOnline", $user_id);
    }

    public function gotoMessenger(Request $request)
    {
        DB::table('user_conversations')
            ->where('id' , $request->c_id)
            ->update(['updated_at'=>NOW()]);
    }
}
