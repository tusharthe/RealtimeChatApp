<?php

namespace App\Http\Controllers;

use App\Notifications\NewPostSubmitNotification;
use App\Post;
use App\User;
use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{

    public function upload_post_image($request)
    {
        if($request->hasFile('file'))
        {
            $files = $request->file('file');
            $fileName = [];
            foreach ($files as $file) {
                $name = uniqid('post_img_').md5($file->getClientOriginalName() . microtime());
                $fileExtension = $file->getClientOriginalExtension();
                $fileName[] = $name_save = $name.'.'.$fileExtension;
                $file->move('photos/postImages',$name_save);
            }
            return $fileName;
        }
    }


    public function store(Post $post,Request $request)
    {
        if($request->postTextarea != '' && $request->postTextarea != null){
            if($post->savenewpost($request))
            { return ['savepost' => true];}
        }
    }
    public function storeimages(Post $post,Request $request){

        if($request->hasFile('file')) {
            $fileName = $this->upload_post_image($request);
            $fileName = json_encode($fileName);
            $postsave = $post->savenewpostwithimage($request, $fileName);
            if ($postsave) {
                return ['savepost' => true];
            }
        }

    }



    public function edit(Post $post,$id)
    {
        $result =  $post->getPostById($id);
        return view('post.edit')->with(compact('result'));
    }

    public function update(Request $request, Post $post)
    {
        return $post->update_post($request);
    }

    public function destroy(Post $post,Request $request)
    {
        $post->where('id', $request->post_id)->where('user_id', $request->post_user_id)->delete();
    }
    public function getAllPost(Post $post, Request $request)
    {
        return  $post->AllUserPost($request);
    }

    public function getPostByUser(Post $post, Request $request)
    {
        return $post->getPostByUser($request);
    }

    public function getPostOfMy(Post $post, Request $request)
    {
        return  $post->getPostOfMy($request);
    }

    public function getPostByFriends(Post $post, Request $request)
    {
        return  $post->getPostByFriends($request);
    }

    public function getPostById(Post $post,$id)
    {
        $result =  $post->getPostById($id);
        return view('post.postbyid')->with(compact('result'));
    }

}
