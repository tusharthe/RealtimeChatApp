<?php

namespace App\Http\Controllers;

use App\PostLike;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PostLikeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(PostLike $postLike)
    {
        //
    }

    public function edit(PostLike $postLike)
    {
        //
    }


    public function update(Request $request, PostLike $postLike)
    {
        //
    }

    public function destroy(PostLike $postLike)
    {
        //
    }

    public function SaveNewLike(PostLike $postLike ,Request $request)
    {
        $db_result = PostLike::where('post_id', $request->id)->get()->toArray();
        $auth_id = Auth::user()->id;
         if(count($db_result) == 0 ){
             $user_id = [];
             $user_id[] = [
                 'liked_at'=>NOW()->format('Y-m-d H:i:s'),
                 'user_id'=>$auth_id,
             ];
             $user_id = json_encode($user_id);
            $result_insert = DB::table('post_likes')->insert(
                 [
                     'post_id' => $request->id,
                     'user_id' => $user_id,
                 ]
             );
            if($result_insert) { return ['success'=>'success','liked'=>'like']; }
         }else{
             $user_id  = json_decode($db_result[0]['user_id']);
               $result_search =  $this->searchForId($auth_id,$user_id);
                if($result_search[0] === true ){
                    $key = $result_search[2];
                    unset($user_id[$key]);
                    $user_id = array_values($user_id);
                    $user_id = json_encode($user_id);
                    $likes = 'unlike';

                }else{
                    $new_id[] = [
                        'liked_at'=>NOW()->format('Y-m-d H:i:s'),
                        'user_id'=>$auth_id,
                    ];

                    $user_id= array_merge_recursive($user_id,$new_id);
                    $user_id = json_encode($user_id);
                    $likes = 'like';
                }
             $result_update=  DB::table('post_likes')->where('post_id', $request->id)->update(
                 [
                     'user_id' => $user_id,
                 ]
             );
             if($result_update) { return ['success'=>'success','liked'=>$likes]; }
         }

    }
    function searchForId($auth_id,$user_id) {
        foreach($user_id as $key => $item)
        {
            if($item->user_id == $auth_id)
            {
               return [true,$auth_id,$key];
            }
        }
        return null;
    }
}
