<?php

namespace App\Http\Controllers;

use App\User;
use App\UserPostComment;
use Illuminate\Http\Request;

class UserPostCommentController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }


    public function store(Request $request)
    {
       $comment = new UserPostComment();
        $comment = $comment->save_post($request);
        if($comment[0] == true){
            $data = [];
            $user = User::find($request->user_id);
            $data[] = [
                'body'=>$request->comment_text,
                'created_at'=>NOW()->format('Y-m-d H:i:s'),
                'id'=>$comment[1],
                'post_id'=>$request->post_id,
                'updated_at'=>NOW()->format('Y-m-d H:i:s'),
                'user'=>$user,
                'user_id'=>$request->user_id,
            ];
            return ['success'=>'true','new_comment'=>$data];

        }else{
            return 'false';
        }
    }

    public function update(Request $request, UserPostComment $userPostComment)
    {
        //
    }

    public function destroy(UserPostComment $userPostComment)
    {
        //
    }
}
