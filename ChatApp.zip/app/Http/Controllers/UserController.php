<?php

namespace App\Http\Controllers;

use App\FriendRequest;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class UserController extends Controller
{
    // return Auth::user()->MyFriends()->get();

    public function MutualFriends(Request $request)
    {
        $user = [];
        $user1 =   User::find($request->id)->friendOf()->get();
        $user2 =   User::find($request->id)->MyFriends()->get();
        $users_1 =  $user2->merge($user1);

        $user1 =   User::find(Auth::user()->id)->friendOf()->get();
        $user2 =   User::find(Auth::user()->id)->MyFriends()->get();
        $users_2 =  $user2->merge($user1);


            foreach($users_1 as $users__1) {
                foreach($users_2 as $users__2) {
                    if($users__1->id == $users__2->id ) {
                        $user[] =  $users__2;
                    }
            }
        }
        return $user;
    }

    public function mergeFriends(Request $request){
            if($request->countOnly == true){
                $user1 =   User::find($request->profileId);
                return $user1->Friends()->count();
            }

        $user1 =   User::find($request->profileId)->friendOf()->limit('5')->offset($request->offset)->with('userProfile')->get();
        $user2 =   User::find($request->profileId)->MyFriends()->limit('5')->offset($request->offset)->with('userProfile')->get();

        $users =  $user2->merge($user1);


            if(Auth::check()){
                foreach ($users as $key => $user) {
                    $users[$key]['type'] =  Auth::user()->isFriend($user->id);

                    $friend = new FriendRequest;
                    $flights = $friend->checkAlreadySendRequest($user->id);
                    if( $flights  ){
                        $users[$key]['request_type'] =  $flights ; }
                    else {
                        $users[$key]['request_type'] = null;
                    }
                }
            }




        // error_reporting(0);
         return ['friends_list'=> $users];


    }
    public function checkAlreadyfriend(Request $request)
    {
        $bool =  Auth::user()->isFriend($request->profileId);
        if($bool)  { return 'true'; }
    }



    public function suggestionFriend(Request $request){

        $user1 =   User::find(Auth::user()->id)->friendOf()->get();
        $user2 =   User::find(Auth::user()->id)->MyFriends()->get();
        $users_2 =  $user2->merge($user1);
        $user[] = 0000;
            foreach ($users_2 as $users) {
                $user[] =  $users->id;
            }

        $query =   DB::table('friend_requests')
            ->where('requester_user', '=', Auth::user()->id )
            ->get();

                foreach ($query as $users_1) {
                    $user[] = $users_1->requested_user;
                }

        array_push($user,Auth::user()->id);

        $users =  User::with('userProfile')->whereNotIn('id', $user)->limit('5')->offset($request->offset)->get();
        if($users){
            return response()->json($users,200);
        }
    }

    public function MyFriend(Request $request)
    {
        if ( Auth::check()) {

            $user = User::find(Auth::user()->id);
            return $user->friends()->toArray();
        }

    }

    public function getUser(Request $request)
    {
           $user = User::with('userProfile')->where('username', $request->username)->first();
           if($user){
               return response()->json(['user' => $user],200);
           }
        return response()->json(['user' => 'false'],201);


    }

    public function get_Notification(Request $request){
        $user = User::find($request->user_id);
        $notification = $user->notifications;
        $count_notification = $user->unreadNotifications->count();
        return ['count'=>$count_notification,'notification'=>$notification];
    }

    public function mark_as_read_Notification(Request $request){
        $user = User::find($request->user_id);
        $notification = $user->unreadNotifications->markAsRead();
        return $notification;
    }

    public function home_side_chat_list(Request $request){
        //return Auth::user()->allOnline()->merge( Auth::user()->Friends());
        $users =  Auth::user()->Friends();

        foreach ($users as $user) {
            if(Cache::has($this->getCacheKey($user->u_id)))
                $user->is_Online = true;
            else
                $user->is_Online = false;
        }
        return $users;

    }
    public function getCacheKey($user_id)
    {
        return sprintf('%s-%s', "UserOnline", $user_id);
    }
    public function get_search_friends(Request $request){
      //  return User::where('name','like' ,'%'.$request->search_word.'%')->orderBy('name','ASC')->get();
         $users =  Auth::user()->Friends();
         $users_search = [];
            foreach ($users as $user) {
                $users_search[] =  $user->id;
            }
         $result =  User::whereIn('id',$users_search)->orderBy('name','ASC')
             ->Where('name','like' ,'%'.$request->search_word.'%')
             ->orderBy('name','ASC')
             ->get();
         return $result;

    }
}
