<?php

namespace App\Http\Controllers;

use App\Events\MessageSenTtoOne;
use App\User;
use App\UserChatMessages;
use Illuminate\Http\Request;
use App\Notifications\NewMessageReceived;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class UserChatMessagesController extends Controller
{


    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
       return view('messenger.index');
    }


    public function store(UserChatMessages $userChatMessages,Request $request)
    {
        $result = $userChatMessages->save_new_message($request);
        if($result['success'] == 1){
                DB::table('user_conversations')
                    ->where('id' , $request->c_id)
                    ->update(['updated_at'=>NOW()]);
            event(new MessageSenTtoOne($result,$request->c_id));
            //dd($result['new_message_saved']['m_to_user']);
            User::find($result['new_message_saved']['m_to_user'])->notify(new NewMessageReceived(Auth::user() ));
            }

        return $result;
    }

    public function update_conversation()
    {


    }


    public function show(UserChatMessages $userChatMessages,Request $request)
    {
        $connnn  = new UserChatMessages;
        return $connnn->Get_chat_messages($request->id);
    }


    public function destroy(UserChatMessages $userChatMessages)
    {

    }
}
