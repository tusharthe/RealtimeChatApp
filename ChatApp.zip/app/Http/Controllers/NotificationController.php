<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use  DB;

class NotificationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function gettopage($username){

        if( Auth::user()->username != $username){
            return redirect('/');
        }else{
            return view('notification.index');
        }
    }

    public function Authuserallnotification (){
       return  Auth::user()->notifications;
    }

    public function markallasreadnotification (){
        Auth::user()->unreadNotifications->markAsRead();
        return 'success';
    }
    public function deleteallnotification (){
        Auth::user()->readNotifications()->delete();
        return 'success';
    }
    public function deletenotification (Request $request){
        DB::table('notifications')->where('id',$request->n_id)->delete();
        return 'success';
    }
    public function markasread (Request $request){
       DB::table('notifications')->where('id',$request->n_id)->update(['read_at'=>NOW()]);
        return 'success';
    }

}
