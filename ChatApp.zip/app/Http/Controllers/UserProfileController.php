<?php

namespace App\Http\Controllers;

use App\Post;
use App\User;
use App\UserProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Validator;
use Illuminate\Validation\Rule;
class UserProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        //
    }

    public function show(UserProfile $userProfile,Request $request)
    {
        $user = User::with('userProfile')->where('username',$request->username)->first();
        if($user){
            return $user;
        }
        return null;

    }

    public function edit(UserProfile $userProfile)
    {
        $user = User::with('UserProfile')->where('id',Auth::id())->get();
        return view('profile.profileedit',compact('user'));
    }


    public function update(Request $request, UserProfile $userProfile)
    {
        $userProfile = new UserProfile();

            if($request->account_section_1 === true) {
                $validator = Validator::make($request->all(), [
                    'name' => 'required|string|max:150',
                    'username' => 'required|string|max:100',
                    'dateofbirth' => 'required|date',
                    'email' => 'required|string|email|max:255',
                ]);
                if (!$validator->fails()) {
                    if($result = $userProfile->account_section_1($request)){ return $result;}
                }else{
                    $errors = $validator->errors();
                    return $errors;
                }
            }

            if($request->account_section_2 === true) {
                $validator = Validator::make($request->all(), [
                    'old_password' => 'required|max:50|min:6',
                    'password' => 'required|string|min:6|confirmed',
                ]);
                if (!$validator->fails()) {
                    if($result = $userProfile->account_section_2($request)){ return $result;}
                }else{
                    $errors = $validator->errors();
                    return $errors;
                }
            }

            if($request->account_section_3 === true) {
                $validator = Validator::make($request->all(), [
                    'nick_name'=> 'min:2|max:20',
                ]);
                if (!$validator->fails()) {
                    if($result = $userProfile->account_section_3($request)){ return $result;}
                }else{
                    $errors = $validator->errors();
                    return $errors;
                }
            }
            if($request->account_section_4 === 'true') {
                if($result = $userProfile->account_section_4($request)){ return $result;}
            }


    }





    public function destroy(UserProfile $userProfile)
    {
        //
    }
    public function username($username)
    {
        if($username){
            return view('profile.profile');
        }
    }


}
