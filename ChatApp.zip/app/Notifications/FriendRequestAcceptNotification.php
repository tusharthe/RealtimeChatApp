<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\BroadcastMessage;

class FriendRequestAcceptNotification extends Notification implements ShouldQueue , ShouldBroadcast
{
    use Queueable;

    public $user;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($user)
    {
        //
        $this->user = $user;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->line($this->user->name.' accept your friend request')
            ->action('View Profile', url('/'.$this->user->username))
            ->line('Thank you for joining us!');
    }

    public function toDatabase($notifiable)
    {
        return [
            'name' => $this->user->name,
            'time' => $this->user->created_at,
            'message' => '  accept your friend request',
            'username' => $this->user->username,
            'type_of' => 'accept_friend_request',
            'profile_pic' => $this->user->profile_pic,
        ];
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'name' => $this->user->name,
            'profile_pic' => $this->user->profile_pic,
            'time' => $this->user->created_at,
            'message' =>' accept your friend request',
            'username' => $this->user->username,
            'type_of' => 'accept_friend_request',
        ];
    }

    public function toBroadcast($notifiable)
    {
        return new BroadcastMessage( [
            'name' => $this->user->name,
            'type_of' => 'accept_friend_request',
            'profile_pic' => $this->user->profile_pic,
            'time' => $this->user->created_at,
            'message' =>' accept your friend request',
            'username' => $this->user->username,
        ]);
    }
}
