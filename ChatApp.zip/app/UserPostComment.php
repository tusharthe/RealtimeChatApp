<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPostComment extends Model
{
    protected $fillable = [
        'user_id','post_id','body'
    ];
    public function user(){
        return  $this->belongsTo('App\User');
    }
    public function post()
    {
        $this->belongsTo('App\Post');
    }

    public function save_post($request)
    {
           $this->user_id  = $request->user_id;
           $this->post_id  = $request->post_id;
           $this->body  = $request->comment_text;
           $this->save();
           return ['true',$this->id];

    }

}
