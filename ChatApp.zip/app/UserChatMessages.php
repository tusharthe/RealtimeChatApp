<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserChatMessages extends Model
{
    protected $fillable = [
        'body','status','from_user','to_user','user_conversation_id','deleted_at'
    ];

    public function Get_chat_messages($con_id){
        if($con_id != null) {
            $query = "SELECT message.id as m_id, message.status as m_status , message.from_user as m_from_user, message.to_user as m_to_user ,message.body as m_body, message.deleted_at as m_deleted_at, message.created_at as m_created_at FROM sns_user_conversations as conversation INNER JOIN sns_user_chat_messages as message where (conversation.id = message.user_conversation_id AND conversation.id =$con_id ) order by message.created_at";
            return DB::select($query);
        }


    }

    public function save_new_message($request){
        $id = Auth::user()->id;
        $this->body = $request->new_message;
        $this->status = 'unread';
        $this->from_user = $id;
        $this->to_user = $request->u_id;
        $this->user_conversation_id = $request->c_id;

        if($Post = $this->save()){
            $b =  [];
                $b['m_to_user']=$request->u_id;
                $b['m_to_user_name']=Auth::user()->name;
                $b['m_status']='unread';
                $b['m_body']=$request->new_message;
                $b['m_id']=$this->id;
                $b['m_from_user']=$id;
                $b['m_created_at']=NOW()->format('Y-m-d H:i:s');
                $b['m_deleted_at']=null;
            return ['success'=>1,'new_message_saved'=>$b];
        }
        return 0;
    }

}
