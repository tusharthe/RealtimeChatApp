<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;
     use \HighIdeas\UsersOnline\Traits\UsersOnlineTrait;

    protected $fillable = [
        'name', 'email', 'password','username','profile_pic','cover_pic','slug_name'
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];
    public function post()
    {
        return $this->hasMany('App\Post');
    }

    public function userProfile()
    {
        return $this->hasOne('App\UserProfile');
    }
    public function friendOf()
    {
        return $this->belongsToMany(User::class, 'friend_lists', 'friend_id', 'user_id');
    }
    public function MyFriends()
    {
        return $this->belongsToMany(User::class, 'friend_lists', 'user_id', 'friend_id');
    }

    public function Friends()
    {
      return $this->MyFriends->merge($this->friendOf);
    }
    public function isFriend($friendId) {
        if( $this->friendOf()->where('users.id', $friendId)->count() || $this->MyFriends()->where('users.id', $friendId)->count() ){
            return true;
        } else{
            return false;
        }
    }
    public function AddFriend($id)
    {
        return $this->MyFriends()->attach($id);
    }

    public function UnFriend($id)
    {
        if($this->friendOf()->detach($id) || $this->MyFriends()->detach($id)) {
            return 'true';
        }
    }




}
