<?php

namespace App;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Broadcast;

class FriendRequest extends Model
{
    protected $fillable = [
        'requested_user','requester_user','status',
    ];

//    protected $dispatchesEvents = [
//        'created' => FriendRequestSend::class,
//    ];

    public function checkAlreadySendRequest($id){
       $requestSend =  FriendRequest::where('requester_user','=',Auth::user()->id )
            ->where('requested_user','=', $id)
            ->where('status','=', 'pending')
            ->count();

       if($requestSend > 0 ){
           return 'request-has-send';
       }

        $acceptRequest =  FriendRequest::where('requester_user','=',$id )
            ->where('requested_user','=', Auth::user()->id )
            ->where('status','=', 'pending')
            ->count();
        if($acceptRequest > 0 ){
            return 'accept-request' ;
        }

    }
}
