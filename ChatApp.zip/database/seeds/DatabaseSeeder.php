<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);

        //      OR
        //TODO
        //



        factory(App\User::class, 150)->create();
        factory(App\UserProfile::class,150)->create();

        factory(App\Post::class, 500)->create();

        $faker = Faker::create();
        for ($x = 0; $x <= 1500; $x++) {
            try {
                    \Illuminate\Support\Facades\DB::table('friend_lists')->insert(
                    [
                        'user_id' => $faker->numberBetween(1, 150),
                        'friend_id' => $faker->numberBetween(1, 150),
                        'created_at' => NOW(),
                        'updated_at' => NOW()

                    ]
                );
            } catch (PDOException $e) {

            }

        }

        for ($x = 0; $x <= 500; $x++) {
        try{
            factory(App\PostLike::class,1)->create();
        }catch (PDOException $e){

             }
        }
        factory(App\UserPostComment::class, 1550)->create();
    }


}
