<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserProfilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_profiles', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->integer('user_id')->unsigned()->unique();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->longText('about')->nullable();
            $table->string('gender')->nullable();
            $table->date('date_of_birth')->nullable();
            $table->string('nickname')->nullable();
            $table->string('school')->nullable();
            $table->string('work')->nullable();
            $table->string('languages')->nullable();
            $table->string('religious_views')->nullable();
            $table->string('relationship')->nullable();
            $table->string('mood_emoji')->nullable();
            $table->string('mood_string')->nullable();
            $table->string('website')->nullable();
            $table->string('current_city')->nullable();
            $table->string('hometown')->nullable();
            $table->string('state')->nullable();
            $table->string('country')->nullable();
            $table->longText('other_info')->nullable();
            $table->bigInteger('phone_number_1')->nullable();
            $table->bigInteger('phone_number_2')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_profiles');
    }
}
