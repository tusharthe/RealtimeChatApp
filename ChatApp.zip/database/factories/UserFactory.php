<?php

use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(App\User::class, function (Faker $faker) {
    $string_name = $faker->name;

    $string = str_replace(' ', '.', $string_name); // Replaces all spaces with hyphens.
    $username =  preg_replace('/[^A-Za-z0-9\-]/', '.', $string); // Removes special chars.

    $profile_imaage  = $faker->randomElements([
        'boy-1.jpg',
        'boy-2.jpg',
        'boy-3.jpg',
        'boy-4.jpg',
        'girl-1.jpg',
        'girl-2.jpg',
        'girl-3.jpg',
        'girl-4.jpg',
        'girl-5.jpg',
        'girl-6.jpg',
        'girl-7.jpg',
    ]);


    return [
        'name' => $string_name,
        'email' => $faker->unique()->safeEmail,
        'username'=> strtolower($username),
        'profile_pic'=> $_ENV['APP_URL'].'photos/user_profile/'.$profile_imaage[0],
        'password' => bcrypt('123456'), //123456
        'remember_token' => str_random(10),
    ];
});
