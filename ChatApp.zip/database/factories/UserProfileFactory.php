<?php

use Faker\Generator as Faker;

$factory->define(App\UserProfile::class, function (Faker $faker) {
    $gender = $faker->randomElements(['male', 'female']);
    $languages = $faker->randomElements(['Hindi', 'English']);
    $relationship = $faker->randomElements(['Single', 'Married','relationship','Engaged','divorced']);
    return [
        'user_id'=> $faker->unique()->numberBetween(1,150),
        'about'=> $faker->paragraph(),
        'gender'=> $gender[0],
        'languages'=> $languages[0],
        'relationship'=> 'single',
        'date_of_birth'=> $faker->date(),
        'nickname'=> $faker->userName(),
        //'cover_pic'=> $faker->image('photos'),
        'mood_emoji'=> $faker->emoji(),
        'current_city'=> $faker->city(),
       // 'hometown'=> $faker->township,
       // 'state'=> $faker->townState,
       // 'country'=> $faker->state,
        'other_info'=> $faker->paragraph(5),

    ];
});
