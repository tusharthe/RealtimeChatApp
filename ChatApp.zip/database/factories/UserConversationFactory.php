<?php

use Faker\Generator as Faker;

$factory->define(App\UserConversation::class, function (Faker $faker) {
    return [
        //
    ];
});
