<?php

use Faker\Generator as Faker;

$factory->define(App\Post::class, function (Faker $faker) {
    $title = $faker->sentence(rand(3,15));
    return [
        'user_id'=> $faker->numberBetween(1,150),
        'content'=> $faker->paragraph(rand(10,50)),
    ];
});
