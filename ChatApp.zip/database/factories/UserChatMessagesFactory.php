<?php

use Faker\Generator as Faker;

$factory->define(App\UserChatMessages::class, function (Faker $faker) {
    return [
        'from_user' => $faker->numberBetween(1, 150),
        'to_user' => $faker->numberBetween(1, 150),
        'body' => $faker->word(rand(50,100)),
    ];
});
