<?php

use Faker\Generator as Faker;

$factory->define(App\UserPostComment::class, function (Faker $faker) {
    return [
        'user_id'=> $faker->numberBetween(1,150),
        'post_id'=> $faker->numberBetween(1,500),
        'body'=> $faker->paragraph(rand(5,10)),
    ];
});
