<?php

use Faker\Generator as Faker;

$factory->define(App\PostLike::class, function (Faker $faker) {

for($i=0 ; $i<=rand(40,100);$i++){
    $user_like[] = [
        'user_id'=> $faker->numberBetween(1,150),
        'liked_at'=> $faker->dateTime(),
    ];
}
    $user_like = json_encode($user_like);
    return [
        'post_id'=> $faker->numberBetween(1,500),
        'user_id'=> $user_like,
    ];
});
