<?php

include 'public_html/index.php';