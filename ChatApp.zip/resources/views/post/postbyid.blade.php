@extends('layouts.app')
@section('page-title')  SNS @endsection
@section('content')
    <div class="container">

        <div class="col-9 offset-2" >
            <post_by_id :result = "{{$result}}" :auth_id="{{Auth::id()}}"></post_by_id>

        </div>
    </div>
@endsection

@push('script')

@endpush
@push('style')

@endpush

