@extends('layouts.app')
@section('page-title')  SNS @endsection
@section('content')
<div class="container" id="fghtjkl">

<div class="row">
    <div id="left-side-bar" class="col-3">

    </div>
		    <home_left_side auth_user="{{ Auth::User() }}"></home_left_side>
			<home_post auth_user_pic="{{ Auth::User()->profile_pic }}" auth_user="{{ Auth::User()->id  }}"></home_post>
			<home_side_chat></home_side_chat>
			
	  
     

    </div>


</div>
@endsection

@push('script')

@endpush
@push('style')
    <style>
        body{
            overflow-y: hidden;
        }
        div#main-center {
            background-color: #fdf5f59e;
            left: calc(25%);
            position: absolute;
            min-height: calc(50%);
            overflow-y: scroll;
            max-height: calc(89%);
            width: 100%;
            padding-bottom: 35px;
            margin-top: 20px;
        }
        div#left-side-bar {
            position: fixed;
            background-color: #eae2e2;
            min-height: calc(97%);

            left: 0;
        }
		div.right-side-bar {
			position: fixed;
			background-color: #eae2e2;
			min-height: calc(97%);
			float: right;
			right: 0;
		}
        .col-md-2.right-side-bar {
            margin-right: 6px;
        }

    </style>
@endpush

