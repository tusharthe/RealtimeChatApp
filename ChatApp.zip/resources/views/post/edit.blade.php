@extends('layouts.app')
@section('page-title')  SNS @endsection
@section('content')
    <div class="container" id="fghtjkl">
       <div class="row">
           <div class="col-3">

           </div>
           <div class="col-7">
               {{--{{$result[0]['images']}}--}}
               @if ( $result[0]['user_id'] !=   Auth::id() )
               {{$url =  route('post_by_id',$result[0]['id']) }}
                   {{--{{ redirect($url)}}--}}
                   <script type="text/javascript">
                       window.location = "{{$url }}";//here double curly bracket
                   </script>
               @else
                   <edit_post :auth_id="{{Auth::id()}}" :result="{{$result[0]}}" ></edit_post>
                @endif
           </div>
           <div class="col-2">

           </div>
       </div>
    </div>
@endsection