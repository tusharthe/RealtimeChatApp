@extends('layouts.app')
@section('page-title')  SNS @endsection
@section('content')
    <div  class="container">
                <div class="row">



                    @if(count($users) > 0)
                        @foreach($users as $user )
                            <div class="center text-center col-3">
                                <div class="card mt-3 mb-3">
                                    <div class="card-body">
                                        <div class="card-img">
                                            <img class="img-thumbnail img-1250" src="{{ $user['profile_pic'] }}" width="150px" height="150px" />
                                        </div>
                                        <div class=" pl-2 card-title">
                                            <span class="text-dark border-light font-weight-bold">{{$user['name']}}</span><br />
                                            <div class="row text-center pl-1"  >
                                                <a class="btn btn-primary btn-sm pt-2 border-light" href="{{  env('APP_URL') . $user['username']}}">See profile</a>
                                                <a class="btn btn-primary btn-sm border-light pt-2 text-white" >{{$user['count_mutual_friend']}} Mutual Friends</a>

                                            </div>

                                        </div>
                                    </div>

                                </div>

                            </div>
                        @endforeach
                    @else
                        <div class="alert-info alert col-12 pt-3 ptb-4 mt-4">Sorry! No Result Was Found for your search</div>
                    @endif


                </div>
    </div>
@endsection



@push('style')
<style>
    img.img-thumbnail.img-1250 {
        width: 200px;
        height: 200px;
    }
</style>
@endpush

@push('script')

@endpush


@push('meta')
    <script> window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?></script>
    <meta name="" content="">
@endpush