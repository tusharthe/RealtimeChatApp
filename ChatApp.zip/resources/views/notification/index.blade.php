@extends('layouts.app')
@section('page-title')  SNS @endsection
@section('content')

    <div class="container-fluid">
        <div class="row">
            <div class="left-side col-3">

            </div>
            <div class="middle-side col-7">
                <notification_page :user="{{ Auth::user() }}"></notification_page>
            </div>
            <div class="right-side col-3">

            </div>
        </div>

    </div>

@endsection