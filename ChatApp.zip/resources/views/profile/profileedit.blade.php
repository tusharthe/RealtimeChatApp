@extends('layouts.app')
@section('page-title') SNS | Edit-Profile @endsection
@section('content')
    <div id="" class="container-fluid">
            <edit_profile auth_user="{{ Auth::id() }}  " details="{{ $user }}"></edit_profile>
    </div>
@endsection



@push('style')

@endpush

@push('script')

@endpush


@push('meta')
    <script> window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?></script>
    <meta name="" content="">
@endpush