@extends('layouts.app')
@section('page-title')  SNS @endsection
@section('content')
    <div id="main-content" class="container-fluid">
        <div  id="profile" >
            @if(Session::has('sendFriendRequestMassage'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                     {{ Session::get('sendFriendRequestMassage') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
          <swtch :loginuserid="{{ Auth::check() ?  Auth::user()->id : 0 }}" :loginusercheck="{{ Auth::check() ?  'true' : 'false' }}"  loading_icon="{{ asset('svg/Spinx.svg') }}" ></swtch>
        </div>
    </div>
@endsection



@push('style')
    <style>
        .nav-tabs {
            border-bottom: 2px solid #53d0d0;
        }

        /* tab color */
        .nav-tabs>li>a {
            background-color: #e8e9fe;
            color: #000;
            font-weight: 700;
            height: 52px;
            padding-top: 14px;
        }

        .nav-tabs .nav-link.active, .nav-tabs .nav-item.show .nav-link {
            color: #495057;
            background-color: #f5f8fa;
            border-color: #dee2e6 #dee2e6 #f5f8fa;
            border-bottom: 3px solid #000000;
        }

        /* active tab color */
        .nav-tabs>li.active>a, .nav-tabs>li.active>a:hover, .nav-tabs>li.active>a:focus {
            color: #fff;
            background-color: #e8e9fe;
            border-radius: 0%;
        }

        /* hover tab color */
        /*.nav-tabs>li>a:hover {*/
            /*border-color: #000000;*/
            /*background-color: #111111;*/
        /*}*/


        body{
            background-color: #e8e9fe;
            //overflow-y: hidden;
        }
        div#main-content {
            margin-top: 18px;
            width: 100%;
        }
    </style>
@endpush

@push('script')

@endpush


@push('meta')
    <script> window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?></script>
    <meta name="" content="">
@endpush