@extends('layouts.app')
@section('page-title')  SNS - Messenger @endsection
@section('content')
    <div class="container-fluid">
        <messenger_index auth_user_id="{{ Auth::User()->id  }}"></messenger_index>
    </div>
@endsection

@push('style')
<style>

    body{
        overflow-y: hidden;
    }
</style>
@endpush

@push('script')

@endpush