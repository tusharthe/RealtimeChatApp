<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    @stack('meta')
    <title> @yield('page-title')</title>
        {{--<script>--}}
            {{--window.Laravel = {!! json_encode([--}}
                {{--'csrfToken' => csrf_token(),--}}
                {{--'user' => Auth::user(),--}}
                {{--'api_token' => (Auth::user()) ? Auth::user()->api_token : null--}}
            {{--]) !!};--}}
        {{--</script>--}}
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    @stack('style')

</head>
<body>
    <div id="app"  >
        <nav class="navbar navbar-expand-md navbar-light nav-fixed navbar-laravel fixed-top">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Laravel') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto" id="header_area">
                        <!-- Authentication Links -->
                        @guest
                            <li><a class="nav-link" href="{{ route('login') }}">Login</a></li>
                            <li><a class="nav-link" href="{{ route('register') }}">Register</a></li>
                        @else
                            <header_search  :user_id="{{ Auth::user()->id }}" ></header_search>
                            <li><a class="nav-link btn btn-sm text-center font-weight-bold" href="{{ route('home') }}">Home</a></li>
                            <header_message  :user_id="{{ Auth::user()->id }}"></header_message>
                            <header_notification :user="{{ Auth::user() }}"  :user_id="{{ Auth::user()->id }}"></header_notification>

                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle btn-sm" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <button  class="dropdown-item btn btn-sm btn-danger" type="button" onclick="window.location.href='{{ env('MIX_VUE_BASE_URL') . Auth::user()->username }}'"  >
                                        My profile
                                    </button>
                                    <button  class="dropdown-item btn btn-sm btn-danger" type="button" onclick="window.location.href='{{ env('MIX_VUE_BASE_URL') . Auth::user()->username .'/profile-edit' }}'"  >
                                        Setting
                                    </button>
                                    <button class="dropdown-item btn btn-sm btn-danger" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        Logout
                                    </button>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>

                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4 mt-4 pt-4" >
                @yield('content')
        </main>
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
    <script src="{{ asset('js/fontawesome-all.min.js') }}"></script>
    @stack('script')
</body>
</html>
