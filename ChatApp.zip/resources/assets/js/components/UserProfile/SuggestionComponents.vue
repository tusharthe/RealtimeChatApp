<template>
    <div>
        <div class="tab-pane fade show active" id="nav-my_friends" @scroll="scrollOccur"   role="tabpanel" aria-labelledby="nav-my_friends-tab">
            <div> <div  id="my_friend" class="container-fluid">
                <div  class="row" >
                    <div class="col-4 text-center"  v-for="(suggestion_user,index) in suggestion"  v-bind:suggestion_user="suggestion_user.id" v-bind:index="index" v-bind:key="suggestion_user.id">
                        <div class="card mt-2">
                            <div class="card-body ">
                                <img class="card-img img-fluid" :src="suggestion_user.profile_pic" :alt="suggestion_user.username" style="width:216px; height: 216px; border-radius: 10px;" >
                                <div class="">
                                    <p class="card-title font-weight-bold">{{ suggestion_user.name }}  </p>
                                    <a  id="user-by-post" :href="suggestion_user.username" class="btn btn-outline-primary">See Profile</a>
                                    <span v-if="loginusercheckfunction">
                                        <span v-if="loginuserid != suggestion_user.id">
                                            <span v-for="">

                                                <span v-if="">
                                                    <a ref="suggestion_user.id" id="is-friend_1" v-if="Add_request_button_compute" @click="sendFriendRequest(suggestion_user.id,suggestion_user.name,index)"  class="btn btn-outline-success">Add Friend</a>
                                                    <a ref="" id="is-friend_2" v-if="cancel_request_button_compute" @click="cancel_request(suggestion_user.id,suggestion_user.name,)"  class="btn btn-outline-danger">Cancel Request</a>
                                                </span>

                                            </span>
                                        </span>
                                  </span>

                                </div>


                            </div>
                        </div>
                    </div>
                </div>


            </div>
            </div>

        </div>
    </div>
</template>

<script>
    export default {
        name: "suggestion-components",
        data: function() {
            return {
                loading: false,
                collapsed: true,
                offset: 0,
                suggestion:[],
                Add_request_button: true,
                cancel_request_button : false,
            }
        },
        props: [
            'loginuserid',
            'profileId',
            'loginusercheck'
        ],
        methods: {
            suggestionFriend: function() {
                this.loading = true;
                axios.post('/suggestionFriend',{
                    offset: this.offset,
                    profileId: this.profileId,
                }).then(response =>  {
                     //console.log(response.data);
                    this.suggestion = this.suggestion.concat(response.data);
                    this.loading = false;
                });
            },
            sendFriendRequest: function ($id,$name,$index) {
                if(this.loginusercheck) {
                    axios.post('/sendFriendRequest',{
                        to: $id,
                        csrfToken: this.csrfToken,
                        sendFriendRequest: true
                    }).then(response =>  {
                        if(response.data == true){
                            this.suggestion.splice($index,1);
                            this.$toaster.success('Request has been send to '+ $name, {timeout: 3000});
                        }
                    });
                }else{
                    this.$toaster.error('First You have To Login!', {timeout: 3000})
                }
            },
            cancel_request : function ($id ,$name) {
                axios.post('/cancel-request',{
                    to: $id,
                    csrfToken: this.csrfToken,
                    cancel_request: true
                }).then(response =>  {

                    if(response.data == true){
                        this.cancel_request_button = false;
                        this.Add_request_button = true;
                        this.$toaster.success('you cancel the friend Request!', {timeout: 3000})
                    }
                });
            },
            scrollOccur: function (event) {
                this.scrolled = window.scrollY > 0;
                var wrapper = event.target,
                    list = wrapper.firstElementChild

                var scrollTop = wrapper.scrollTop,
                    wrapperHeight = wrapper.offsetHeight,
                    listHeight = list.offsetHeight

                var diffHeight = listHeight - wrapperHeight
                // console.log(diffHeight,scrollTop);
                if(diffHeight <= scrollTop && !this.loading){

                    this.offset = this.offset + 5;
                    //  console.log(this.offset);
                    this.suggestionFriend();
                }
            },
        },
        created: function() {
            window.addEventListener('scroll', this.scrollOccur);
            this.suggestionFriend();

        },
        destroyed: function () {
            window.removeEventListener('scroll', this.scrollOccur);
        },
        computed : {
            Add_request_button_compute : function(){
                return this.Add_request_button == true;
            },
            cancel_request_button_compute: function () {
                    return this.cancel_request_button == true;
            },
            loginusercheckfunction: function () {
                return this.loginusercheck == true ;
            },
        }
    }
</script>

<style scoped>

</style>