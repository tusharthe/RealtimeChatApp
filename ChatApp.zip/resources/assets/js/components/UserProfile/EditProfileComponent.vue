<template xmlns="http://www.w3.org/1999/html">
    <div class="">
        <link href="https://cdn.jsdelivr.net/npm/animate.css@3.5.1" rel="stylesheet" type="text/css">
        <div class="pt-4   container-fluid col-9 ">

            <div class="profile_pic">

                <div class="alert alert-info" style="" @click="show4 = !show4">
                    <i class="fas fa-arrow-right" v-bind:hidden="show4"></i>
                    <i class="fas fa-arrow-down" v-bind:hidden="!show4"></i>
                    Change Profile Pic
                </div>

                <transition name="slide-fade" >

                    <div v-if="show4">
                        <form method="post" action="/update/account_section_edit" v-on:submit="onSubmit4" enctype="multipart/form-data" id="account-section-4" class="form-control">

                        <div class="form-group">
                            <label>Select Photo: </label>
                            <input type="file"  v-on:change="image_load" accept="image/*" class="form-control"  name="user_photo" required  />
                        </div>
                        <div class="pb-2 mb-2 text-center center" :hidden="base_image === null">
                            <!-- Note that 'ref' is important here (value can be anything). read the description about `ref` below. -->
                            <vue-croppie
                                    ref=croppieRef
                                    :enableOrientation="true"
                                    @result="result"
                                    :viewport="{ width: 350, height: 350}"
                                    :boundary="{ width: 400, height: 400}"
                                    @update="update">
                            </vue-croppie>

                            <!-- the result -->
                            <!--<img v-bind:src="cropped" />-->

                            <!--<button @click="bind()">Bind</button>-->
                            <!-- Rotate angle is Number -->
                            <button type="button" class="btn btn-sm btn-info" @click="rotate(-90)">Rotate Left</button>
                            <button type="button" class="btn btn-sm btn-info" @click="rotate(90)">Rotate Right</button>
                            <button type="button" class="btn btn-sm btn-outline-success" @click="crop()">Crop</button>
                            <button type="button" class="btn btn-sm btn-secondary" @click="undo()">undo/redo</button>
                            <button type="button" class="btn btn-sm btn-warning" @click="reset_data()">reset</button>
                            <button type="button" class="btn btn-sm btn-danger" @click="destroy()">Cancle</button>
                            <button type="submit" name="account-section-4"  class="btn btn-sm btn-success">Save</button>

                            <!--<button @click="cropViaEvent()">Crop</button>-->
                        </div>
                        </form>
                    </div>
                </transition>

            </div>
            <div class="general-account">

                    <div class="alert alert-info" style="" @click="show = !show">
                            <i class="fas fa-arrow-right" v-bind:hidden="show"></i>
                            <i class="fas fa-arrow-down" v-bind:hidden="!show"></i>
                        General Setting
                    </div>

                    <transition name="slide-fade" >

                        <div v-if="show">
                            <form method="post" action="/update/account_section_edit" v-on:submit="onSubmit1" id="account-section-1" class="form-control">

                            <div class="form-group">
                                <label>Full Name: </label>
                                <input type="text" class="form-control" autocomplete="off"  name="name" required placeholder="Change your Name" v-bind:value="user_details.name" />
                            </div>


                            <div class="form-group">
                                <label>Username: </label>
                                <input type="text" disabled class="form-control" autocomplete="off"  required readonly name="username" placeholder="Username" v-bind:value="user_details.username" />
                            </div>


                            <div class="form-group">
                                <label>Date of birth: </label>
                                <input type="date"  class="form-control"  required autocomplete="off"  name="dateofbirth" placeholder="dateofbirth" v-bind:value="user_details.user_profile.date_of_birth" />
                            </div>


                            <div class="form-group">
                                <label>E-mail: </label>
                                <input type="email" class="form-control" autocomplete="off"  name="email" required placeholder="Change Your E-mail" v-bind:value="user_details.email" />
                            </div>

                                <div class="form-group">
                                    <button type="submit" name="account-section-1"  class="btn btn-sm btn-success float-right">Save</button>
                                </div>
                            </form>

                        </div>
                    </transition>

            </div>
            <div class="password-account">

                <div class="alert alert-info" style="" @click="show2 = !show2">
                    <i class="fas fa-arrow-right" v-bind:hidden="show2"></i>
                    <i class="fas fa-arrow-down" v-bind:hidden="!show2"></i>
                    Security Setting
                </div>

                <transition name="slide-fade" >

                    <div v-if="show2">
                        <form method="post" action="/update/account_section_edit" v-on:submit="onSubmit2" id="account-section-2" class="form-control">

                            <div class="form-group">
                                <label>Old Password: </label>
                                <input type="password" class="form-control" autocomplete="off" required  name="old_password" placeholder="Enter Your Old Password" value="" />
                            </div>


                            <div class="form-group">
                                <label>New Password: </label>
                                <input type="password"  class="form-control" autocomplete="off" required name="password" placeholder="Enter Your New Password" value="" />
                            </div>


                            <div class="form-group">
                                <label>Confirm Password  </label>
                                <input type="password" class="form-control" autocomplete="off" required name="password_confirmation" placeholder="Enter Confirm Password" value="" />
                            </div>

                            <div class="form-group">
                                <button type="submit" name="account-section-2" class="btn btn-sm btn-success float-right">Save</button>
                            </div>
                        </form>

                    </div>
                </transition>

            </div>
            <div class="other-setting">

                <div class="alert alert-info" style="" @click="show3 = !show3">
                    <i class="fas fa-arrow-right" v-bind:hidden="show3"></i>
                    <i class="fas fa-arrow-down" v-bind:hidden="!show3"></i>
                    Other Setting
                </div>
                <keep-alive>
                <transition name="slide-fade" >

                    <div v-if="show3">
                        <form method="post" action="/update/account_section_edit" v-on:submit="onSubmit3" id="account-section-3" class="form-control">

                            <div class="form-group">
                                <label>About: </label>
                                <textarea type="text" class="form-control" autocomplete="off"  name="about" placeholder="About Yourself">{{user_details.user_profile.about}}</textarea>
                            </div>

                            <div class="form-group">
                                <label>Nick Name: </label>
                                <input type="text" class="form-control" autocomplete="off"  name="nick_name" placeholder="Nick Name" v-bind:value="user_details.user_profile.nickname"/>
                            </div>

                            <div class="form-group">
                                <label>Hometown: </label>
                                <input type="text" class="form-control" autocomplete="off"  name="hometown" placeholder="Home Town" v-bind:value="user_details.user_profile.hometown"/>
                            </div>

                            <div class="form-group">
                                <label>Country: </label>
                                <input type="text" class="form-control" autocomplete="off"  name="country" placeholder="Country" v-bind:value="user_details.user_profile.country"/>
                            </div>



                            <div class="form-group">
                                <label>State: </label>
                                <input type="text" class="form-control" autocomplete="off"  name="state" placeholder="state" v-bind:value="user_details.user_profile.state"/>
                            </div>

                            <div class="form-group">
                                <label>Phone Number 1: </label>
                                <input type="tel" class="form-control"   name="phone_number_1" placeholder="Phone Number" v-bind:value="user_details.user_profile.phone_number_1"/>
                            </div>

                            <div class="form-group">
                                <label>Phone Number 2: </label>
                                <input type="tel" class="form-control"  name="phone_number_2" placeholder="Phone Number" v-bind:value="user_details.user_profile.phone_number_2"/>
                            </div>

                            <div class="form-group">
                                <label>Your Website: </label>
                                <input type="text" class="form-control" autocomplete="off"  name="website" placeholder="Website" v-bind:value="user_details.user_profile.website"/>
                            </div>

                            <div class="form-group">
                                <label>Relationship Status: </label>
                                <select class="form-control">
                                    <option>Single</option>
                                </select>
                            </div>



                            <div class="form-group">
                                <button type="submit" name="account-section-3" class="btn btn-sm btn-success float-right">Save</button>
                            </div>
                        </form>

                    </div>
                </transition>
                </keep-alive>

            </div>
        </div>
        <div class="pt-4  container-fluid col-3">
            <vue-snotify></vue-snotify>
            <!--<flash-message class="myCustomClass"></flash-message>-->
            </div>
    </div>
</template>

<script>

    export default {
        name: "Edit_Profile",
        props: [
            'details',
            'auth_user',
        ],
        data: function () {
            return {
                user_details : '',
                show: false,
                show2: false,
                show3: false,
                show4: false,
                base_image : null,
                cropped: null,
                reset: null,
                undo_action: null,
                reset_action: null,
            }
        },
        methods : {
            onSubmit1: function(e) {
                e.preventDefault();
                axios.post(e.target.action,{
                    name : e.target.elements['name'].value,
                    email : e.target.elements['email'].value,
                    username : e.target.elements['username'].value,
                    dateofbirth : e.target.elements['dateofbirth'].value,
                    account_section_1 : true,
                }).then(response =>  {
                    this.$snotify.success(response.data, {timeout: 2000,showProgressBar: false,});
                });

            },
            undo () {
                this.base_image =  this.undo_action ;
                this.bind();
            },
            reset_data () {
                this.base_image = this.reset;
                this.bind();
            },
            destroy() {
                this.base_image = null;
                this.cropped = null;
                this.show4 = false;
            },
            image_load : function(e) {
                let files = e.target.files;
                let reader = new FileReader();
                reader.readAsDataURL(files[0]);
                reader.onload = e => {
                   // console.log(e.target.result);
                    this.base_image = e.target.result;
                    this.reset =  this.base_image;
                    this.bind();
                }

            },
            onSubmit4: function(e) {
                e.preventDefault();
                let form  = new FormData();
                console.log(this.base_image);
                form.append('image_bse64',this.base_image);
                form.append('account_section_4','true');
                axios.post(e.target.action,form).then(response =>  {
                   // console.log(response.data);
                    this.base_image = null;
                    this.cropped = null;
                    this.show4 = false;
                    this.$snotify.success(response.data, {timeout: 2000,showProgressBar: false,});
                 });
            },
            bind() {
                this.$refs.croppieRef.bind({
                    url: this.base_image,
                });
            },
            crop() {
                this.$refs.croppieRef.result((output) => {
                    this.cropped = output;
                });
            },
            cropViaEvent() {
                let options = {
                    format: 'jpeg',
                    circle: true
                }
                this.$refs.croppieRef.result(options);
            },
            result(output) {
                this.cropped = output;
                this.base_image = this.cropped;
                this.bind();
            },
            update(val) {
                // console.log(val);
            },
            rotate(rotationAngle) {
                this.$refs.croppieRef.rotate(rotationAngle);
            },
            onSubmit2: function(e) {
                e.preventDefault();
                axios.post(e.target.action,{
                    old_password : e.target.elements['old_password'].value,
                    password : e.target.elements['password'].value,
                    password_confirmation : e.target.elements['password_confirmation'].value,
                    account_section_2 : true,
                }).then(response =>  {
                    // this.$snotify.success(response.data, {timeout: 2000,showProgressBar: false,});

                    // this.flash('Post was Success updated.', 'success',{timeout: 5000});

                    if(response.data.old_password) {
                        this.$snotify.success(response.data.old_password[0], {timeout: 5000,showProgressBar: false,});
                    }
                    if(response.data.password) {
                        this.$snotify.success(response.data.password[0], {timeout: 5000,showProgressBar: false,});
                    }
                    if(response.data === 'Password Was Successfully Change') {
                        this.$snotify.success(response.data, {timeout: 5000,showProgressBar: false,});
                    }
                    if(response.data === 'Old Password Doesn\'t match') {
                        this.$snotify.success(response.data, {timeout: 5000,showProgressBar: false,});
                    }

                });

            },
            onSubmit3: function(e) {
                e.preventDefault();
                axios.post(e.target.action,{
                    about : e.target.elements['about'].value,
                    nick_name : e.target.elements['nick_name'].value,
                    hometown : e.target.elements['hometown'].value,
                    country : e.target.elements['country'].value,
                    state : e.target.elements['state'].value,
                    phone_number_1 : e.target.elements['phone_number_1'].value,
                    phone_number_2 : e.target.elements['phone_number_2'].value,
                    website : e.target.elements['website'].value,
                    account_section_3 : true,
                }).then(response =>  {

                    if(response.data.nick_name) {
                        this.$snotify.success(response.data.nick_name[0], {timeout: 5000,showProgressBar: false,});

                        return null;
                    }
                    this.$snotify.success(response.data, {timeout: 3000,showProgressBar: false,});

                });

            }
        },
        watch : {
            show : function () {
                   return this.show;
            } ,
            user_details : function () {
                   return this.user_details;
            } ,
            base_image : function (after, before) {
                this.redo_action = after;
                this.undo_action = before;
                return this.base_image;
            },
            undo_action : function () {
                return this.undo_action;
            },
            undo: function () {

                return this.undo();
            },
            cropped : function () {
                return this.cropped;
            },
            bind : function () {
                return this.bind();
            }  ,
            crop : function () {
                return this.crop();
            }
        },
        created : function()
        {
            this.user_details = JSON.parse(this.details);
            this.user_details = this.user_details[0];

        },

    }
</script>

<style scoped>
    form#account-section-1,#account-section-2,#account-section-3,#account-section-4{
        padding-bottom: 45px;
        margin-bottom: 30px;
    }
    .slide-fade-enter-active {
        transition: all .3s ease;
    }
    .slide-fade-leave-active {
        transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0);
    }
    .slide-fade-enter, .slide-fade-leave-to
        /* .slide-fade-leave-active below version 2.1.8 */ {
        transform: translateX(10px);
        opacity: 0;
    }
    .general-account { width: 100% }


</style>