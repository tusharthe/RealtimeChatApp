<template>
    <div>

        <div class="tab-pane fade show active" id="nav-posts"  @scroll="scrollOccur" role="tabpanel" aria-labelledby="nav-posts-tab">
            <div><div class="" v-for="user in users"  >
                <post v-for="(post, index) in user.post "
                      v-bind:post="post.id"
                      v-bind:index="index"
                      v-bind:key="post.id"
                      :profile_pic="user.profile_pic"
                      :name="user.name"
                      :images="post.images"
                      :username="user.username"
                      :updated_at="post.updated_at"
                      :post_content="post.content"
                      :post_user_id="user.id"
                      :post_id="post.id"
                      :likes="post.likes[0]"
                      :comments="post.comments"
                      :auth_user="loginuserid"
                      :videoId="post.youtube_link"
                      v-on:delete_post="delete_post()"
                ></post>
            </div></div>



        </div>

    </div>

</template>

<script>
    var moment = require('moment');
    import post from './PostComponent.vue';
    export default {
        name: "user_post",
        data: function() {
          return {
              loading: false,
              collapsed: true,
              users: [],
              posts: [],
              username: '',
              offset: 0,
              list: [],

          }

        },
        props: [
            'loginuserid',
            'profileId',
            'loginusercheck'
        ],
        components : {
            post
        },
        methods: {
            delete_post : function () {
                this.$snotify.success('Post Was Deleted Successfully', {timeout: 5000,showProgressBar: false,  position: 'leftTop'});
                this.users = [];
                this.getPostByUser();
            },
            getPostByUser: function() {
                this.loading = true;
                axios.post('/getPostByUser',{
                    offset: this.offset,
                    username: this.username,
                }).then(response =>  {
                    this.users = this.users.concat(response.data);
                      //console.log(this.offset);
                    this.loading = false;
                    Vue.filter('time_filter',function (value) {
                        return  moment(value).fromNow();
                    });
                });
            },

            likeComputed: function (value) {
                if (!value) return false;
                if(JSON.parse(value.user_id).length === 0) return false;
                var obj = {};
                obj =  JSON.parse(value.user_id);
                var new_value = this.auth_user;
                obj.forEach(function(element) {
                    if(element.user_id == new_value) {
                        return true;
                    }
                });
                return false;
            },
            scrollOccur: function (event) {
                this.scrolled = window.scrollY > 0;
                var wrapper = event.target,
                    list = wrapper.firstElementChild

                var scrollTop = wrapper.scrollTop,
                    wrapperHeight = wrapper.offsetHeight,
                    listHeight = list.offsetHeight

                var diffHeight = listHeight - wrapperHeight
                 // console.log(diffHeight,scrollTop);
                if(diffHeight <= scrollTop && !this.loading){

                    this.offset = this.offset + 3;
                    //  console.log(this.offset);
                    this.getPostByUser();
                }
            },
        },
        watch :{
            csrfToken:function () {
                return this.csrfToken;
            },
            like:function () {
                return this.like;
            },
            likeComputed:function () {
                return this.likeComputed;
            },
            comments : function () {
                return this.comments;
            }
        },
        created: function() {
            this.username = window.location.pathname.split('/')[1];
            window.addEventListener('scroll', this.scrollOccur);
            this.getPostByUser();

        },
        destroyed: function () {
            window.removeEventListener('scroll', this.scrollOccur);
        }
    }
</script>

<style scoped>

</style>