<template>
<div>

    <div class="tab-pane fade show active" id="nav-my_friends"    role="tabpanel" aria-labelledby="nav-my_friends-tab">
        <div><div  id="my_friend" class="container-fluid">
            <div class="row" v-if="my_friends[0] != ''" >
                <div class=" col-4 text-center"  v-for="(my_friend,index) in my_friends"  v-bind:my_friend="my_friend.id" v-bind:index="index" v-bind:key="my_friend.id">
                    <div class="card mt-2">
                        <div class="card-body ">
                            <img class="card-img img-fluid" :src="my_friend.profile_pic" :alt="my_friend.username" style="width:216px; height: 216px; border-radius: 10px" >
                            <div class="mb-0 pt-1">
                                <p class="card-title font-weight-bold">{{ my_friend.name }}  </p>
                                <a  id="user-by-post" :href="my_friend.username" class="btn btn-outline-primary">See Profile</a>
                                <a  id="is-friend2" v-if="my_friend.id != loginuserid " @click="OnButtonClicked(my_friend.id,index)" class="btn btn-outline-warning">UnFriend</a>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal -->
            <div class="modal fade" id="RemoveFriendRequestByUser" tabindex="-1" role="dialog" aria-labelledby="RemoveFriendRequestByUser" aria-hidden="true">
                <div class="modal-dialog modal-dialog-sm modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            Conform to unfriend ?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" @click="RemoveFriendRequestByUser()" data-dismiss="modal" class="btn btn-primary">Unfriend</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        </div>

    </div>


</div>
</template>

<script>
    export default {
        name: "mutual-friends-components",
        data: function() {
            return {
                loading: false,
                collapsed: true,
                username: '',
                offset: 0,
                my_friends:[],
                unFriendValue : 0,
                indexvalue : 0,

            }
        },
        watch: {
            unFriendValue: function () {
                return this.unFriendValue ;
            },
            indexvalue: function () {
                return this.indexvalue ;
            },
            usernamebyProfile: function () {
                return this.usernamebyProfile ;
            },
        },
        props: [
            'loginuserid',
            'profileId',
            'loginusercheck'
        ],
        methods:{

            MutualFriends: function () {
                this.loading = true;
                axios.post('/MutualFriends',{
                    id: this.profileId,
                }).then(response =>  {
                    this.my_friends = this.my_friends.concat(response.data);
                    this.loading = false;
                   // console.log(response.data);
                });
            },
            RemoveFriendRequestByUser: function () {
                axios.post('/sendFriendRequest',{
                    to: this.unFriendValue,
                    csrfToken: this.csrfToken,
                    RemoveFriendRequest: true
                }).then(response =>  {
                    if(response.data == true){
                        this.$toaster.success(this.usernamebyProfile+ ' removed from your friend list', {timeout: 3000});
                        var index = this.indexvalue;
                        this.my_friends.splice(index,1);
                    }
                });
            },
            OnButtonClicked: function ($id,$index) {
                this.unFriendValue = $id;
                this.indexvalue = $index;
                $("#RemoveFriendRequestByUser").modal('show');
            },
        },
        created: function() {

            this.MutualFriends();
        },

    }
</script>

<style scoped>

</style>