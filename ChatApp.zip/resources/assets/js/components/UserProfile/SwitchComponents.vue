<template>

    <div class="container-fluid">
        <div class="row" v-if="userFound != false">
            <div class="col-md-3 col-sm-3 col-3" >
                <div>   <img :src="user.profile_pic" class="rounded-circle border border-secondary mx-auto d-block img-fluid img-thumbnail" id="profile_pic" alt="">
                    <div class="mt-2 pt-1">
                        <h5 class="alert-link text-center " data-toggle="tooltip" data-html="true" title="Name">{{ user.name }}</h5>
                        <h6 v-if="user.user_profile.work" class="text-center">Work: {{ user.user_profile.work }}</h6>
                        <h6 v-if="user.user_profile.state" class="text-center">state: {{ user.user_profile.state }}</h6>

                        <div class="text-center">
                            <div v-if="loginuserid != user.id" class="btn-group pb-3 " role="group" aria-label="Basic example">
                                <div class="row">
                                    <button id="CancelAcceptRequest" v-if="CancelAcceptRequestComputed"  @click="cancel_request(user.id)" class="btn  btn-outline-dark">Cancel <img v-show="loading_icon_show"  width="20px" height="20px"  :src="loading_icon" /></button>
                                    <button id="AcceptFriendButton" v-if="AcceptRequestComputed" @click="AcceptFriendRequestFunction(user.id)" class="btn  btn-outline-dark">Accept Friend <img  v-show="loading_icon_show" width="20px" height="20px"  :src="loading_icon" /></button>
                                    <button id="CancelSendRequest" v-else-if="CancelRequestButtonComputed"  @click="cancel_request(user.id)" class="btn  btn-outline-dark">Cancel Request <img v-show="loading_icon_show"  width="20px" height="20px"  :src="loading_icon" /></button>
                                    <button id="addFriendButton" v-else-if="AlreadyFriendcomputed" @click="sendFriendRequest(user.id)" class="btn  btn-outline-dark">Add Friend <img v-show="loading_icon_show"  width="20px" height="20px" :src="loading_icon" />  </button>
                                    <button id="unFriendButton" v-else data-toggle="modal" data-target="#RemoveFriendRequest" class="btn  btn-outline-dark">Unfriend <img  v-show="loading_icon_show" width="20px" height="20px"  :src="loading_icon" /></button>
                                    <!--<button id="follow_user" class="btn  btn-outline-dark">Follow</button>-->

                                    <!--<button id="" class="btn btn-sm btn-outline-success"><span> 250</span> Followers</button>-->
                                    <!--<button id="" class="btn btn-sm btn-outline-success"><span> 140</span> Following</button>-->
                                    <button id="" class="btn btn-sm btn-outline-success"><span> {{ friendsCount }}</span> Friends</button>
                                </div>
                            </div>



                        </div> <br />
                        <!-- Modal -->
                        <div class="modal fade " id="RemoveFriendRequest" tabindex="-1" role="dialog" aria-labelledby="RemoveFriendRequest" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-sm modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        Conform to unfriend ?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="button" @click="RemoveFriendRequest(user.id)" data-dismiss="modal" class="btn btn-primary">Unfriend</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div v-if="user.user_profile.about !== null " class="some-css-41250">
                            <span class="text-left some-css-12450">About:</span>
                            <span class="text-capitalize some-css-2-4510">{{ user.user_profile.about }}</span>
                            <br />
                        </div>
                        <div v-if="user.user_profile.date_of_birth !== null " class="some-css-41250">
                            <span class="text-left some-css-12450">Date of Birth:</span>
                            <span class="text-capitalize some-css-2-4510">{{ user.user_profile.date_of_birth }}</span>
                            <br />
                        </div>
                        <div v-if="user.user_profile.gender !== null " class="some-css-41250">
                            <span class="text-left some-css-12450">Gender:</span>
                            <span class="text-capitalize some-css-2-4510">{{ user.user_profile.gender }}</span>
                            <br />
                        </div>
                        <div v-if="user.user_profile.nickname !== null " class="some-css-41250">
                            <span class="text-left some-css-12450">Nickname:</span>
                            <span class="text-capitalize some-css-2-4510">{{ user.user_profile.nickname }}</span>
                            <br />
                        </div>
                        <div v-if="user.user_profile.website !== null " class="some-css-41250">
                            <span class="text-left some-css-12450">Website:</span>
                            <span class="text-capitalize some-css-2-4510">{{ user.user_profile.website }}</span>
                            <br />
                        </div>
                        <div v-if="user.user_profile.country !== null " class="some-css-41250">
                            <span class="text-left some-css-12450">Country:</span>
                            <span class="text-capitalize some-css-2-4510">{{ user.user_profile.country }}</span>
                            <br />
                        </div>




                    </div>
                </div>
            </div>
            <div class="col-md-9 col-sm-9 col-9">
                <!-- Nav pills -->
                <!-- Nav tabs -->
                <ul class="nav nav-tabs"  id="nav-tab" role="tablist">
                    <li class="nav-item" @click="components = 'user_post'"  >
                        <a class="nav-link active"   data-toggle="tab" id="nav-posts-tab" href="#user-posts"  aria-controls="nav-posts" aria-selected="true"><span v-if="loginuserid == user.id ">My</span>  Posts</a>

                    </li>
                    <li class="nav-item"  @click="components = 'user_friend'" >
                        <a class="nav-link"  data-toggle="tab" id="nav-my-tab" href="#user-friends"  role="tab" aria-controls="nav-friends" aria-selected="true"><span v-if="loginuserid == user.id ">My</span> Friends</a>

                    </li>
                    <li class="nav-item"  v-if="mutual_friends" @click="components = 'MutualFriendsComponents'">
                        <a class="nav-link" data-toggle="tab" id="nav-mutual-tab" href="#mutual-friends"  role="tab" aria-controls="nav-mutual-friends" aria-selected="true">Mutual Friends</a>
                    </li>
                    <li class="nav-item" v-if="Suggestionfuction"  @click="components = 'SuggestionComponents'">
                        <a class="nav-link" data-toggle="tab" id="nav-Suggestions-tab" href="#Suggestions-friends"  role="tab" aria-controls="nav-Suggestions-friends" aria-selected="true">Suggestions</a>
                    </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content mt-4 " id="nav-tabContent">
                    <keep-alive>

                        <components :loading_icon="loading_icon" :loginuserid="loginuserid" :loginusercheck="loginusercheck" :profileId="profileId" v-bind:is="components"></components>


                    </keep-alive>

                </div>
            </div>
        </div>

        <div v-else>
            <delay :wait="800">
                <div class=" container mt-4 pt-4 text-center align-middle col-8">
                    <h1 class="page-wrapper display-4">Oops! Could Not Found Page.</h1>
                    <h3 class="">The requested page doesn't exit. <br />
                        May be page is temporary unavailable or move to new location.

                    </h3>


                </div>
            </delay>
        </div>


    </div>




</template>

<script>
    var moment = require('moment');
    import user_post from './User_PostComponent.vue';
    import user_friend from './User_FriendsComponent.vue';
    import MutualFriendsComponents from './MutualFriendsComponents.vue';
    import SuggestionComponents from './SuggestionComponents.vue';
    export default {
        name: "switch-components",
        components: {
            'user_post' : user_post,
            'user_friend':user_friend,
            'MutualFriendsComponents': MutualFriendsComponents,
            'SuggestionComponents': SuggestionComponents,

        },
        props: [
            'loginuserid',
            'loginusercheck',
            'loading_icon'

        ],
        data : function() {
            return{
                components : 'user_post',
                user : [],
                profileId : '',
                userFound : false,
                friendsCount : '',
                AlreadyFriend : false,
                CancelRequestButton : false,
                FriesndByAuth : [],
                AcceptRequest: false,
                CancelAcceptRequest: false,
                loading_icon_show: false,

            }
        },
        methods :  {
            cancel_request : function ($id) {
                this.loading_icon_show = true;
                axios.post('/cancel-request',{
                    to: $id,
                    csrfToken: this.csrfToken,
                    cancel_request: true
                }).then(response =>  {
                    if(response.data == true){
                        this.loading_icon_show = false;
                        this.AlreadyFriend = false;
                        this.CancelRequestButton = false;
                        this.CancelAcceptRequest = false;
                        this.AcceptRequest = false;
                        this.$toaster.success('you cancel the friend Request!', {timeout: 3000})
                    }
                });
            },
            AcceptFriendRequestFunction : function ($id) {
                this.loading_icon_show = true;
                axios.post('/AcceptFriendRequestUrl',{
                    to: $id,
                    csrfToken: this.csrfToken,
                    AcceptFriendRequest: true
                }).then(response =>  {
                    this.loading_icon_show = false;
                    this.$toaster.success(this.user.name +' add to your friend list !', {timeout: 5000})
                        this.AlreadyFriend = true;
                        this.CancelRequestButton = false;
                        this.CancelAcceptRequest = false;
                        this.AcceptRequest = false;

                });

            },
            sendFriendRequest: function ($id) {
                if(this.loginusercheck) {
                        this.loading_icon_show = true;
                        axios.post('/sendFriendRequest',{
                        to: $id,
                        csrfToken: this.csrfToken,
                        sendFriendRequest: true
                    }).then(response =>  {
                        if(response.data == true){
                            this.loading_icon_show = false;
                            this.AlreadyFriend = true;
                            this.CancelRequestButton = true;
                            this.$toaster.success('Request has been send to '+ this.user.name, {timeout: 3000})
                        }
                    });
                }else{
                    this.$toaster.error('First You have To Login!', {timeout: 3000})
                }
            },
            getFriesndByAuth: function () {
                axios.post('/MyFriend').then(response =>  {
                      // console.log(response.data);
                       this.FriesndByAuth = response.data;

                });
            },
            RemoveFriendRequest: function ($id) {
                this.loading_icon_show = true;
                axios.post('/sendFriendRequest',{
                    to: $id,
                    csrfToken: this.csrfToken,
                    RemoveFriendRequest: true
                }).then(response =>  {
                    this.loading_icon_show = false;
                    if(response.data == true){
                       this.AlreadyFriend = false;
                        this.$toaster.success(this.user.name +' remove from your friend list !', {timeout: 3000})
                    }
                });
            },
            checkAlreadyfriend: function () {
                axios.post('/checkAlreadyfriend',{
                    profileId: this.profileId,
                }).then(response =>  {
                    if(response.data == true){
                            this.AlreadyFriend = true;
                           // console.log(response.data);
                    }else{
                        this.AlreadyFriend = false;
                        this.SomeFunction();

                    }

                });
            },
            SomeFunction: function () {
                axios.post('/checkAlreadySendRequest',{
                    to: this.user.id,
                    checkAlreadySendRequest: true
                }).then(response =>  {
                   // console.log(response.data );
                    if(response.data == 'request-has-send') {
                        this.AlreadyFriend = true ;
                        this.CancelRequestButton = true ;
                    }else if(response.data == 'accept-request'){
                        this.AcceptRequest = true;
                        this.CancelAcceptRequest = true;
                        this.$toaster.success('Can you accept '+this.user.name +' friend request!', {timeout: 3000})
                    }
                    else{
                        this.AlreadyFriend = false ;
                        this.CancelRequestButton = false ;
                        this.AcceptRequest = false;
                    }
                });
            },
            getUser($username){
                    axios.post('/getUser',{
                        username: $username,
                    }).then(response =>  {
                        if(response.data.user != 'false')
                        {
                            this.userFound = true;
                            this.user = response.data.user;
                            this.profileId = response.data.user.id;
                            this.mergeFriendsCount();
                            this.getFriesndByAuth();
                            if(this.profileId  != this.loginuserid && this.loginuserid != 0){
                                this.checkAlreadyfriend();
                            }


                        }else{
                            this.userFound = false;
                        }


                    });
            },
            mergeFriendsCount: function() {
                axios.post('/mergeFriends',{
                    profileId: this.profileId,
                    countOnly : 'true',
                }).then(response =>  {
                    this.friendsCount = this.friendsCount.concat(response.data);
                });
            },
        },
        created: function() {
            this.csrfToken = $('meta[name="csrf-token"]').attr('content');
            this.username = window.location.pathname.split('/')[1];
            this.getUser(this.username);
        },
        computed : {
            AcceptRequestComputed: function () {
                return this.AcceptRequest == true;
            },
            mutual_friends: function () {
                return this.loginuserid  != this.user.id  && this.loginusercheck != false
            },
            Suggestionfuction: function () {
                return  this.loginusercheck != false
            },
            AlreadyFriendcomputed: function () {
                return  this.AlreadyFriend != true
            },
            CancelRequestButtonComputed: function () {
                return  this.CancelRequestButton == true
            },
            CancelAcceptRequestComputed : function () {
                return this.CancelAcceptRequest == true;
            }
        }
    }
</script>

<style >
    .some-css-41250 {
        font-size: 15px;
        font-family: serif;
        font-kerning: none;
        margin: 4px -8px 4px 0;
        font-weight: 100;
    }
    .tab-pane{
        position: absolute;
        overflow-y: scroll ;
        height: 480px;
        width: 95%;

    }
    img#profile_pic {
        width: 200px;
        height: 200px;
    }
    span.text-left.some-css-12450 {
        font-weight: 700;
        font-size: 16px;
        font-family: sans-serif;
        color: black;
        padding: 5px 7px 5px 0px;
    }
    span.text-capitalize.some-css-2-4510 {
        word-break: break-word;
        word-spacing: normal;
        word-wrap: break-word;
    }
</style>