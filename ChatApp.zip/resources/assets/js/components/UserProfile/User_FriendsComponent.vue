<template>
    <div>
        <div class="tab-pane fade show active" id="nav-my_friends" @scroll="scrollOccur"   role="tabpanel" aria-labelledby="nav-my_friends-tab">
            <div><div  id="my_friend" class="container-fluid">
                <div class="row" >
                    <div class="col-md-4 col-sm-6 col-lg-4 text-center"  v-for="(Friend_By_Profile,index,key) in Friends_By_Profile"  v-bind:Friend_By_Profile="Friend_By_Profile.id" v-bind:index="index" v-bind:key="Friend_By_Profile.id">
                        <div class="card mt-2">
                            <div class="card-body ">
                                <img class="card-img img-fluid" :src="Friend_By_Profile.profile_pic" :alt="Friend_By_Profile.username" style="width:216px; height: 216px; border-radius: 10px " >
                                <div class="mb-0 pt-1">
                                    <p class="card-title font-weight-bold">{{ Friend_By_Profile.name }} </p>

                                    <a  id="user-by-post" :href="Friend_By_Profile.username" class="btn btn-outline-primary">See Profile</a>
                                    <span v-if="loginusercheckfunction">
                                        <span v-if="loginuserid != Friend_By_Profile.id">
                                            <a   v-if="request_type(Friend_By_Profile.request_type,Friend_By_Profile.id)" @click="cancel_request(Friend_By_Profile.id,Friend_By_Profile.username)" class="btn btn-outline-secondary">Cancel Request</a>
                                            <a  id="accept_button_" v-else-if="request_type(Friend_By_Profile.request_type,index)"  class="btn btn-outline-info">Accept Request</a>
                                            <a  :id="Friend_By_Profile.id" v-else-if="Friend_By_Profile.type != true"  @click="sendFriendRequest(Friend_By_Profile.id,Friend_By_Profile.name,key)"  class="btn btn-outline-success">Add Friend</a>
                                            <a  id="remove_button_"  v-else @click="OnButtonClicked(Friend_By_Profile.id,index)" class="btn btn-outline-warning">UnFriend</a>
                                        </span>
                                  </span>

                                </div>


                            </div>
                        </div>
                    </div>
                </div>


            </div>
            </div>

        </div>
        <!-- Modal -->
        <div class="modal fade" id="RemoveFriendRequestByUser" tabindex="-1" role="dialog" aria-labelledby="RemoveFriendRequestByUser" aria-hidden="true">
            <div class="modal-dialog modal-dialog-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        Conform to unfriend ?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" @click="RemoveFriendRequestByUser()" data-dismiss="modal" class="btn btn-primary">Unfriend</button>
                    </div>
                </div>
            </div>
        </div>

    </div>

</template>

<script>
    export default {
        name: "user_friend",
        data: function() {
            return {
                loading: false,
                collapsed: true,
                username: '',
                offset: 0,
                Friends_By_Profile:[],
                MyFriendByAuth:[],
                checkUserIsmyFriendData: false,
                CancelRequestButton : false,
                unFriendValue : 0,
                indexvalue : 0,
                request_has_send : false,
                accept_request: false,
                usernamebyProfile:'',
            }
        },
        watch: {
            unFriendValue: function () {
                return this.unFriendValue ;
            },
            indexvalue: function () {
                return this.indexvalue ;
            },
            usernamebyProfile: function () {
                return this.usernamebyProfile ;
            },
            request_has_send: function () {
                return this.request_has_send ;
            },
            accept_request: function () {
                return this.accept_request ;
            },
        },
        props: [
            'loginuserid',
            'profileId',
            'loginusercheck'
        ],
        methods:{
            cancel_request : function ($id,$username) {
                axios.post('/cancel-request',{
                    to: $id,
                    csrfToken: this.csrfToken,
                    cancel_request: true
                }).then(response =>  {
                    if(response.data == true){
                        this.Friends_By_Profile = [];
                        this.mergeFriends();
                        this.$toaster.success('you cancel the friend Request!', {timeout: 3000})
                    }
                });
            },
              request_type: function($value,$id){
                if($value == 'request-has-send'){
                    this.request_has_send = true;
                    return   this.request_has_send;
                }else if($value == 'accept-request') {
                    this.accept_request = true;
                    return this.accept_request;
                }
            },
            sendFriendRequest: function ($id,$username,$key) {
              //  $("#"+$key).show();
                if(this.loginusercheck) {
                    axios.post('/sendFriendRequest',{
                        to: $id,
                        csrfToken: this.csrfToken,
                        sendFriendRequest: true
                    }).then(response =>  {
                        if(response.data == true){
                            $("#"+$id).hide();
                            this.$toaster.success('Request has been send to '+ $username, {timeout: 3000})
                        }
                    });
                }
            },
            RemoveFriendRequestByUser: function () {
                axios.post('/sendFriendRequest',{
                    to: this.unFriendValue,
                    csrfToken: this.csrfToken,
                    RemoveFriendRequest: true
                }).then(response =>  {
                    if(response.data == true){
                        this.$toaster.success(this.usernamebyProfile+ ' removed from your friend list', {timeout: 3000});
                        var index = this.indexvalue;
                        this.Friends_By_Profile.splice(index,1);
                    }
                });
            },
            OnButtonClicked: function ($id,$index) {
                this.unFriendValue = $id;
                this.indexvalue = $index;
                $("#RemoveFriendRequestByUser").modal('show');
            },
            mergeFriends: function() {
                this.loading = true;
                axios.post('/mergeFriends',{
                    offset: this.offset,
                    profileId: this.profileId,
                }).then(response =>  {
                    // console.log(response.data);
                     this.Friends_By_Profile = this.Friends_By_Profile.concat(response.data.friends_list);
                     this.loading = false;
                });
            },
            scrollOccur: function (event) {
                this.scrolled = window.scrollY > 0;
                var wrapper = event.target,
                    list = wrapper.firstElementChild

                var scrollTop = wrapper.scrollTop,
                    wrapperHeight = wrapper.offsetHeight,
                    listHeight = list.offsetHeight

                var diffHeight = listHeight - wrapperHeight
                // console.log(diffHeight,scrollTop);
                if(diffHeight <= scrollTop && !this.loading){

                    this.offset = this.offset + 5;
                    //  console.log(this.offset);
                    this.mergeFriends();
                }
            },
        },
        created: function() {
            window.addEventListener('scroll', this.scrollOccur);
            const csrfToken = $('meta[name="csrf-token"]').attr('content');
            this.mergeFriends();

        },
        destroyed: function () {
            window.removeEventListener('scroll', this.scrollOccur);
        },
        computed : {
            loginusercheckfunction: function () {
                return this.loginusercheck == true ;
            },
        }
    }
</script>

<style scoped>

</style>