<template>
    <div class="col-12 " v-if="open">
        <div  id="comment-section">
            <div class="text-center" id="no-comment-yet" v-if="comments_array == '' ">
                <span class="text-center" >no Comment yet</span>
            </div>
            <div v-else>
                <singlecomment v-for="comment in comments_array" :key="comment.id"
                    :body="comment.body"
                    :comment_id="comment.id"
                    :created_at="comment.created_at"
                    :post_id="comment.post_id"
                    :user="comment.user"
                    :auth_user_id="auth_user"
                ></singlecomment>
            </div>
            <div class="comment-textbox col-12">
                <form>
                    <div class="row">
                        <textarea v-model="comment_text" class="form-control mt-2 pb-2 " rows="1" placeholder="type your comment..."></textarea>
                    </div>
                    <div class="row">
                        <div class="float-right mt-2 pb-1">
                            <button type="reset" @click="cancle_comment()"  class="btn btn-sm btn-outline-danger">cancel</button>
                            <button type="button" @click="submit_comment()" class="btn btn-sm btn-outline-success">submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
    var moment = require('moment');
    import singlecomment from './CommentComponent.vue'
    export default {
        name: "home-post-comment-component",
        props : [
            'post_comments',
            'open',
            'post_id' ,
            'auth_user',
        ],
        data : function () {
          return {
              comment_text : '',
              comments_array : [],
          }
        },
        components:{
            singlecomment
        },
        created : function () {
          this.comments_array = this.post_comments;
        },
        watch: {
            open : function () {
                return this.open;
            } ,
            post_comments : function () {
                return this.post_comments;
            },
            comments_array : function () {
                return this.comments_array;
            }
        },
        methods : {
            cancle_comment : function () {
              this.comment_text   = '';
            },
          submit_comment : function () {
                if(this.comment_text != '')
              axios.post('/savecomment',{
                    user_id : this.auth_user,
                    post_id : this.post_id,
                    comment_text : this.comment_text,
              }).then(response => {
                        if(response.data.success == 'true'){
                            this.comment_text = '';
                            this.comments_array = this.comments_array.concat(response.data.new_comment);
                        }
              });

          }
        }
    }
</script>

<style scoped>
#comment-section{
    border-top: 1px solid #8c8c8c;
    width: 100%;
    min-height: 75px;
    margin-top: 10px;

}
div#no-comment-yet {
    font-family: monospace;
}
</style>