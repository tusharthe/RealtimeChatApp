<template>
    <div class="list__wrapper"  >
        <div id="main-center" class="col-7"   @scroll="scrollOccur"  >
            <div  >
                <div >
                    <div class="card" >
                        <div class="card-header" id="card-header">
                            <div class="row">
                                <div class="col-12">
                                    <div class="position-absolute text-capitalize" > <i class="fas fa-pencil-alt"></i>Make Post |</div>
                                    <div class="position-absolute ml-5 pl-5 text-capitalize" > <i class="fas fa-camera-retro"></i> Image\Videos</div>
                                </div>
                            </div>
                        </div>
                        <form method="post" enctype="multipart/form-data" @submit.prevent="submitPost()">
                            <div class="card-body ">
                                <div class="row">
                                    <div class="col-12">
                                        <img :src="auth_user_pic"  width="40px" height="40px" style="border-radius: 100%;" />
                                        <textarea v-model="postTextarea" v-on:focus=" collapsed = false"   v-autosize="" id="post-textarea"  class="card-text from-control col-11" rows="2" :placeholder="placeholderValue" ></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body ">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-lg-3 col-md-6 col-sm-12">
                                            <div @click="collapsedImageFunction()" v-if="collapsedImageButton == true" class="file-upload-post pt-1 pb-1 text-center">
                                                <span style="margin: 0"  class=""><b>photos/videos</b></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <vue-dropzone  v-if="collapsedImage!=true"  v-on:vdropzone-success-multiple="showSuccessOfImages" v-on:vdropzone-sending-multiple="vdropzoneSending" v-on:vdropzone-error=""  v-on:vdropzone-files-added="vdropzonefilesadded" v-on:vdropzone-file-added-manually="vdropzonefilesadded"  ref="myVueDropzone" id="dropzone"  :options="dropzoneOptions" />
                                    </div>
                                </div>
                            </div>

                            <div class="card-footer container float-right"  v-bind:class="{'is-collapsed' : collapsed }">
                                <div class="row">
                                    <div class="col-6">
                                        <!--<button type="button" class="btn-info post-type-button btn btn-sm float-left">type</button>-->
                                    </div>
                                    <div class="col-6">
                                        <button type="submit"  class="btn-light post-submit-button btn btn-sm float-right">post</button>
                                        <button type="reset" @click="cancel_post"  class="btn-danger post-reset-button btn btn-sm float-right mr-2">cancel</button>
                                    </div>
                                </div>

                            </div>
                        </form>



                    </div>
                    <vue-snotify></vue-snotify>
                    <div id="post-new-post" class="list__item"  v-for="(user, index) in users" v-bind:user="user.id" v-bind:index="index" v-bind:key="user.id">
                    <post
                        v-on:delete_post="delete_post()"
                        v-for="(post, index) in user "
                        v-bind:post="post.id"
                        v-bind:index="index"
                        v-bind:key="post.id"
                        :profile_pic="post.user.profile_pic"
                        :name="post.user.name"
                        :images="post.images"
                        :username="post.user.username"
                        :updated_at="post.updated_at"
                        :post_content="post.content"
                        :post_user_id="post.user.id"
                        :post_id="post.id"
                        :likes="post.likes[0]"
                        :comments="post.comments"
                        :auth_user="auth_user"
                        :videoId="post.youtube_link"
                        ></post>
                    </div>

                    <div v-if="users[0].length > 0" class="pb-4 mb-4 post-placeholders card-body ">
                        <content-placeholders :rounded="true">
                            <content-placeholders-heading :lines="1" :img="true" />
                        </content-placeholders>
                        <div class="placeholders-lines mr-4 pr-4"></div>
                        <content-placeholders :rounded="true">
                            <content-placeholders-text :lines="3" />
                        </content-placeholders>

                    </div>
                    <div v-else class="alert alert-secondary mt-4 col-12">
                            No post to show. Please upload posts or make new friends.
                    </div>

                </div>
            </div>
        </div>

    </div>
</template>

<script>

   // import Vue from vue/vue;
   import vue2Dropzone from 'vue2-dropzone'
   import VueStar from 'vue-star'
   import post from './PostComponent.vue'
   var moment = require('moment');
    export default {
        name: "home-post-component",
        components: {
            vueDropzone: vue2Dropzone,
            VueStar,
            post
        },
        props : [
          'auth_user',
          'auth_user_pic'
        ],
        data: function() {
            return{
                placeholderValue:'whats on your mind? Type Here',
                posts : [],
                list: [],
                offset: 0,
                loading: false,
                collapsed: true,
                collapsedImage: true,
                collapsedImageButton:true,
                csrfToken : '',
                postTextarea: '',
                users: [],
                vue_dro_zone_enable : false,
                dropzoneOptions: {
                    url: '/createPostImage',
                    maxFilesize: 300,
                    duplicateCheck: true,
                    uploadMultiple: true,
                    dictDefaultMessage: "<i class='fas fa-cloud-upload-alt'></i> Click here or Drag flies here to Upload",
                    dictRemoveFile: "Remove",
                    // previewTemplate: '<div> Long template here </div>',
                    thumbnailWidth: 120,
                    autoProcessQueue:false,
                    thumbnailHeight: 120,
                    addRemoveLinks: true,
                    parallelUploads : 50,
                    maxFiles : 50,
                    //acceptedFileTypes : "image/*",
                    // headers: { "X-CSRF-TOKEN": this.csrfToken }
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                }

            }
        },
        methods: {
            delete_post : function () {
                this.$snotify.success('Post Was Deleted Successfully', {timeout: 2000,showProgressBar: false,});
                this.postTextarea ='';
                this.users = [];
                this.collapsed= true;
                this.collapsedImage= true;
                this.collapsedImageButton=true;
                this.getPostByFriends();
            },
            showSuccessOfImages: function (file,response) {
               if(response.savepost){
                   this.$toaster.success('Post has been submit ',{timeout: 3000});
                   this.postTextarea ='';
                   this.users = [];
                   this.collapsed= true;
                   this.collapsedImage= true;
                   this.collapsedImageButton=true;
                   this.placeholderValue='whats on your mind? Type Here';
                   this.getPostByFriends();
               }
            },
            vdropzoneSending: function (file, xhr, formData) {
                formData.append("postTextarea", this.postTextarea);
            },
            vdropzonefilesadded:function (files) {
                this.vue_dro_zone_enable = true;
            },
            likeComputed: function (value) {
                if (!value) return false;
                if(JSON.parse(value.user_id).length === 0) return false;
                var obj = {};
                obj =  JSON.parse(value.user_id);
                var new_value = this.auth_user;
                obj.forEach(function(element) {
                    if(element.user_id == new_value) {
                        return true;
                    }
                });
                return false;
            },

            cancel_post : function () {
                this.collapsedImage = true;
                this.collapsedImageButton = true;
                this.collapsed = true;
                this.postTextarea = '';
                this.vue_dro_zone_enable = false;
                this.placeholderValue='whats on your mind? Type Here';
            },
            getURLSegment: function (){
                return window.location.pathname.split('/')[1];
            },

            scrollOccur: function (event) {
                this.scrolled = window.scrollY > 0;
                var wrapper = event.target,
                    list = wrapper.firstElementChild

                var scrollTop = wrapper.scrollTop,
                    wrapperHeight = wrapper.offsetHeight,
                    listHeight = list.offsetHeight

                var diffHeight = listHeight - wrapperHeight
                //  console.log(diffHeight,scrollTop);
                if(diffHeight <= scrollTop && !this.loading){
                    this.offset =  this.offset + 5;
                    this.getPostByFriends();
                }
            },
            collapsedImageFunction: function (event){
                this.collapsed = false;
                this.collapsedImage=false;
                this.collapsedImageButton=false;
                this.placeholderValue = 'say something about your photos'
            },
            getPostByFriends: function() {
                this.loading = true;
                axios.post('/getPostByFriends',{
                    offset: this.offset,
                }).then(response =>  {
                    //console.log(response.data);
                    this.users = this.users.concat(response.data);
                    this.loading = false;
                    Vue.filter('time_filter',function (value) {
                        return  moment(value).fromNow();
                    });
                });
            },
            submitPost: function () {

                if(this.vue_dro_zone_enable){
                  return  this.$refs.myVueDropzone.processQueue();
                }
                if(this.postTextarea != '' && !this.vue_dro_zone_enable){
                    axios.post('/createPost',{
                        postTextarea: this.postTextarea,
                    });
                    this.$toaster.success('Post has been submit ',{timeout: 3000});
                    this.postTextarea ='';
                    this.users = [];
                    this.collapsed= true;
                    this.collapsedImage= true;
                    this.collapsedImageButton=true;
                    this.getPostByFriends();
                }
            }
        },
        watch :{
            csrfToken:function () {
                return this.csrfToken;
            },
            like:function () {
                return this.like;
            },
            likeComputed:function () {
                return this.likeComputed;
            },
            comments : function () {
                return this.comments;
            }
        },
        computed : {

        },
        created: function() {
            window.addEventListener('scroll', this.scrollOccur);
            this.csrfToken = $('meta[name="csrf-token"]').attr('content');
            this.getPostByFriends();
        },

        destroyed: function () {
            window.removeEventListener('scroll', this.scrollOccur);
        }
    }
</script>

<style>
    span.count-likes {
        padding: -14px;
        margin-left: 25px;
    }
    .VueStar__ground {
        margin-top: -25px;
        width: 28px;
        height: 26px;
    }
    .VueStar__decoration {
        width: 88px;
        height: 88px;
        position: absolute;
        margin-left: -34px;
        margin-top: -28px;
    }
</style>
<style scoped>
    img.preview {
        width: 200px;
        background-color: white;
        border: 1px solid #DDD;
        padding: 5px;
    }
    .file-upload-post {
        width: auto;
        border: 1px solid #7b7979;
        border-radius: 20px;
        background: #eae4e478;
    }
    .is-collapsed {
        display: none;
    }
    .vue-content-placeholders-text {
        margin-left: 72px;
        width: 85%;
    }
    div#card-header {
        height: 38px;
        margin-top: -9px;
    }
    .post-placeholders {
        margin: 5px 0 0 19px;
    }
    button.post-submit-button {

        border: 1px solid black;
        color: #000000;
        font-family: monospace;
        font-size: 14px;
    }
    button.post-reset-button {

        border: 1px solid black;
        color: #000000;
        font-family: monospace;
        font-size: 14px;
    }
    button.post-type-button {

        border: 1px solid black;
        color: #000000;
        font-family: monospace;
        font-size: 14px;
    }
    .button-class {
        margin-top: 8px;
        background-color: #ffffff;
        height: 45px;
        width: 100%;
    }
    div#post-side-icon {
        margin-top: -79px;
    }
    textarea#post-textarea {
    //  position: relative;
        float: right;
        border-radius: 0%;
        border: none;
        width: 92%;
        resize: none;
    }
    textarea#post-textarea:focus {
        outline: none;
    }
    div#post-dropdown {
        margin-left: 30px;
        min-width: 77px;
        background-color: #dbdbe2;
        font-size: 14px;
        font-family: serif;
    }
    span.post-likes {
        font-size: 15px;
        color: #007bff;
        margin-left: 7px;
        cursor: pointer;
    }
</style>