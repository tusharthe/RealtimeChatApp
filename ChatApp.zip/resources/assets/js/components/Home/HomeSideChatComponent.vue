<template>
    <div class="col-md-2 right-side-bar" >

        <div class="pt-2 margin-set ">
            <li class="list-group-item pointer disabled active">Contacts</li>
           <ul class="list-group scroll-y ">
                <li v-for="user in users" class="list-group-item pointer hover">
                    <div class="row style-margin"  v-on:click="gotomessanger(user)">
                        <div class="style-image-div-1250"><img class="style-image-1250" :src="user.profile_pic"  />
                           <span class="name-14520">{{ user.name }}</span>
                            <span v-if="user.is_Online != true" v-bind:style="StyleColor_red" class="float-right online-offline indicator"></span>
                            <span v-else v-bind:style="StyleColor_green" class="float-right online-offline indicator"></span>
                        </div>
                    </div>
                </li>
            </ul>

            <div v-if="users.length === 0" class="alert alert-warning mt-4 col-11">
                No contact list.<br /> Make new friends.
            </div>
        </div>

    </div>


</template>

<script>
    export default {
        name: "home_side_chat_component",
        data: function(){
            return {
                errors: [],
                users:[],
                StyleColor_green : ' background-color: green;',
                StyleColor_red : ' background-color: red;',
            }
        },
        methods:{
          get_all_user_online(){
              axios.post(`/home_side_chat_list`)
                  .then(response => {
                    this.users = this.users.concat(response.data);
                  })
                  .catch(e => {
                      this.errors.push(e)
                  })
          },
            gotomessanger(user) {
                axios.post(`/user_select_search_result`,{
                     selected_friend : user.id,
                });
                window.location.href = "messenger";
            }
        },
        created(){
                 this.get_all_user_online();
        },

    }
</script>

<style scoped>
    img.style-image-1250 {
        height: 34px;
        width: 34px;
        border-radius: 100%;
    }
    span.name-14520 {
        font-size: 12px;
        padding-left: 2px;
        font-family: sans-serif;
        font-weight: lighter;
    }
    li.list-group-item.pointer {
        cursor: pointer;
    }
    ul.list-group.scroll-y{
        overflow-y: scroll;
        position: absolute;
        height: calc(82%);
        width: 99%;
    }
    .margin-set {
        margin-left: -11px;
        margin-right: -17px;
    }

    .scroll-y::-webkit-scrollbar {
        width: 6px;
    }

    .scroll-y::-webkit-scrollbar-track {
        -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
        border-radius: 10px;
    }

    .scroll-y::-webkit-scrollbar-thumb {
        border-radius: 10px;
        -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5);
    }
    li.list-group-item.pointer.hover:hover {
        background-color: #dddfe2;
    }
    li.list-group-item.pointer.hover {
        background-color: #f1f1f1c2;
        height: 50px;
    }

    .row.style-margin {
        margin-top: calc(-4px);
    }
    span.float-right.online-offline.indicator {
        height: 9px;
        width: 9px;
        right: 11px;
        border-radius: 100%;
        position: absolute;
        margin-top: calc(-22px);
    }
</style>