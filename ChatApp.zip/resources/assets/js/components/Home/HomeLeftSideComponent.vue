<template>
    <div id="left-side-bar">

             <div class="text-center user mt-4 pl-4 pt-2 ml-2" >
                 <img :src="user.profile_pic" class="rounded-circle border border-secondary mx-auto d-block img-fluid img-thumbnail" id="profile_pic" alt="">
                <div class="some-thing-4520">
                    <span id="user-name">{{user.name}}</span>
                    <div>
                        <a class="same-class-12" :href="setting" >Account Setting</a><br />
                        <a class="same-class-12" :href="user.username" >See Profile</a><br />
                        <a class="same-class-12" href="messenger" >Messages</a><br />
                        <a class="same-class-12" :href="notification" >Notification</a><br />

                    </div>
                </div>


             </div>


    </div>
</template>

<script>
    export default {
        name: "HomeLeftSideComponent",
        props : [
            'auth_user',
        ],
        data : function () {
            return {
                user : [],
                notification : '',
                setting : '',

            }
        },
        created : function () {
            this.user = JSON.parse(this.auth_user);
            this.notification = this.user.username + '/notifications/';
            this.setting = this.user.username + '/profile-edit/';
        }
    }
</script>

<style scoped>
    img#profile_pic {
        width: 200px;
        height: 200px;
    }
</style>