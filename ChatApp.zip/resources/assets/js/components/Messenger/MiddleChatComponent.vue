<template>
    <div>
        <div v-if="chat_user == ''" class="text-center mt-4 ml-3">
            <delay :wait="1000">
                 <div class="alert alert-danger text-center">Search friend to start chat</div>
            </delay>
        </div>
        <div v-else>
        <li class="list-group-item active">
            <div class="row">
                <span class="pr-1"><img :src="chat_user.u_profile_pic" width="25px" height="25px" style="border-radius: 100%;margin-top: 5px;"/></span>
                <span class="mt-1"> <a style="color: white" :href="chat_user.u_username">{{ chat_user.u_name }}</a> </span>

            </div>


        </li>
        <ul class="list-group" v-chat-scroll>

            <li class="padding-by-me" v-for="chat_message in chat_messages">

                <P v-if="chat_message.m_from_user == auth_user_id" class="list-group-item  mt-2 mb-2 float-right justify-content-between">
                    <span  style="white-space: pre;">{{ chat_message.m_body }}</span>
                    <span class="font-italic position-static" id="time"><br />at {{ chat_message.m_created_at | time_filter }}</span>
                </P>

                <P v-else class="list-group-item  float-left mt-2 mb-2  justify-content-between">
                    <span style="white-space: pre;" >{{ chat_message.m_body }}</span>
                    <span class="font-italic position-static" id="time"><br />at {{ chat_message.m_created_at | time_filter}}</span>
                </P>
            </li>
            <div > <img v-for="count in counting" class="float-right" :src="loading_mess" />
            </div>



        </ul>
       <div class="row">
            <textarea v-model="new_message" required type="text" class="form-control new-message" placeholder="Type your message" > </textarea>
            <span style="border-radius: 0" class="btn btn-dark" v-on:click="save_new_chat_messages()" >Send </span>
        </div>
    </div></div>

</template>

<script>
    export default {
        name: "middle-chat-component",
        props:[
            'auth_user_id',
            'chat_user',
            'conversation_id'
        ],
        watch: {
            chat_user : function(after, before) {
                this.message = '';
                this.chat_messages= [];
                this.get_chat_messages();
                return  this.chat_user;
            },
            float_right : function(after, before) {
                return  this.float_right;
            },
            counting : function() {
                return  this.counting;
            },

        },
        data:function () {
            return {
                new_message : '',
                chat_messages: [],
                get_new_message : [],
                loading_image : 'message-loading.svg',
                counting : 0,
            }
        },
        computed:{
                listclassName: function(){ return ['list-group-item-'+this.color, 'float-'+this.float];  },


        },
        created : function () {
            this.base_url =  process.env.MIX_VUE_BASE_URL;
            this.loading_mess = this.base_url+'svg/'+this.loading_image;
        },
        methods :{
            get_chat_messages : function () {
                this.chat_messages = [];
                axios.post(`/get_chat_messages`,{
                   id : this.chat_user.c_id,
                }).then(response => {
                     this.chat_messages = response.data;
                    Vue.filter('time_filter',function (value) {
                        return  moment(value).format('LT, ll');
                    });
                })
            },
            save_new_chat_messages : function () {

                if(this.new_message != '' || this.new_message != null) {
                    this.counting++;
                    axios.post(`/save_new_chat_messages`,{
                        c_id : this.chat_user.c_id,
                        u_id : this.chat_user.u_id,
                        new_message : this.new_message,
                    }).then(response => {
                        this.counting--;
                        this.chat_messages = this.chat_messages.concat(response.data.new_message_saved);
                        this.$emit('new_message_event',response.data.new_message_saved);
                    });
                }

                this.new_message = '';
            },

        },
        mounted() {

            Echo.private('private.message.conversation.'+ this.auth_user_id)
                .listen('MessageSenTtoOne', (e) => {
                     if(e[1] === this.chat_user.c_id){
                         this.chat_messages = this.chat_messages.concat(e[0].new_message_saved);
                        this.$emit('new_message_event',e[0].new_message_saved.m_to_user_name);
                     }else {
                     }

                });

        }
    }


</script>

<style scoped>
    li.padding-by-me {
        padding-left: 2px;
        padding-right: 4px;
    }
    div.offline-indicator {
        background: red;
        color: white;
    }
    .list-group{
        overflow-y: scroll;
        height: 450px;

    }
    .list-group-item{
        max-width: 80%;
        word-wrap:break-word;
        border-bottom: 1px;
        border-style: solid;
        box-shadow: 0 0 6px 0px #4e555b;
        overflow: auto;
    }

    li.list-group-item.active {
        max-width: 100%;
    }
    span#time {
        font-size: 11px;
        font-weight: 500;
        color: #007bff;
        padding-left: 5px;
    }
    textarea.form-control.new-message {
        resize: none;
        width: 90%;
        border-radius: 0;
        outline: none;
        -webkit-box-shadow: none;
        box-shadow: none;
        /*border-color: inherit;*/
        transition:box-shadow 0.5s ease;
        /*box-sizing:border-box;*/
        /*direction:rtl;*/
        display:block;

    }
    textarea.form-control.new-message:hover {
        border-color: inherit;
        outline: none;
        -webkit-box-shadow: none;
        box-shadow: none;
    }

</style>