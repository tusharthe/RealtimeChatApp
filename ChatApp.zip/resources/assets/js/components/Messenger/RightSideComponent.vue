<template>
    <div>
        <div v-if="chat_user != ''" class="container-fluid mt-4 center text-center ">
            <img class="img img-thumbnail " :src="chat_user.u_profile_pic" width="200px" height="200px"  />
            <h3 class="pt-3">{{ chat_user.u_name }}</h3>
        </div>
    </div>
</template>

<script>
    export default {
        name: "right-side-component",
        props:[
            'auth_user_id',
            'chat_user'
        ],
        watch: {
            chat_user : function(after, before) {
                return  this.chat_user;
            },
        },
        data:function () {
            return {

            }
        },
    }
</script>

<style scoped>

</style>