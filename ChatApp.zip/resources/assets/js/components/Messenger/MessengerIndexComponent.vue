<template>
    <div>
        <div class="row">
            <div class="col-3 left-side-bar" >

                <left_sidebar v-bind:chat_user_prop="chat_user" v-bind:auth_user_id="auth_user_id"  v-on:change_User="update_change_User($event)"></left_sidebar>

            </div>
            <div class="col-6 middle-center">
                <middle_chat v-bind:chat_user="chat_user"  v-bind:auth_user_id="auth_user_id"  v-on:new_message_event="new_message_event_update($event)" ></middle_chat>
            </div>
            <div class="col-3 right-side-bar">
                <right_side v-bind:chat_user="chat_user" v-bind:auth_user_id="auth_user_id" ></right_side>
            </div>
        </div>
    </div>
</template>

<script>

    import left_sidebar from './LeftSidebarComponent.vue' ;
    import right_side from './RightSideComponent.vue' ;
    import middle_chat from './MiddleChatComponent.vue' ;
    import { bus } from '../../app.js';

    export default {
        name: "messenger_index",
        data:function () {
          return {
              chat_user  : [],
          }
        },
        props:[
            'auth_user_id',
        ],
        watch: {
            chat_user : function(after, before) {
                return  this.chat_user;
            },
        },
        methods : {
            update_change_User : function (chat_uer_details) {
                this.chat_user = chat_uer_details;
            } ,
            new_message_event_update : function ($new_messagrr) {
                this.$snotify.success('All are Marked as read', {timeout: 2000,showProgressBar: false,});
                bus.$emit('new_message_event_to_header');

            },

        },
        components :{
           'left_sidebar': left_sidebar,
            'right_side' : right_side,
            'middle_chat' : middle_chat,
        }

    }
</script>

<style scoped>
    .col-6.middle-center {
        left: calc(24%);
        position: fixed;
        width: 100%;
        height: 100%;
    }
    .col-3.left-side-bar {
        height: 100%;
        position: fixed;
        width: 100%;
        left: 0;
    }
    .col-3.right-side-bar {
        right: 0;
        position: fixed;
        width: 100%;
        height: 100%;
    }

</style>