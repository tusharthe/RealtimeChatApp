<template>
    <div class="pt-2 margin-set ">
        <li class="list-group-item pointer disabled active">
            <input type="search"  v-model="search_friends" class="form-control" placeholder="search friends by name"  />
        </li>
        <div v-if="search == true">
            <ul class="list-group scroll-y ">
                <li  v-for="user in users_search_result" class="list-group-item pointer hover" v-on:click="event_search_friend_id(user)">
                    <div class="row style-margin"  >
                        <div class="style-image-div-1250"><img class="style-image-1250" :src="user.profile_pic"  />
                            <span class="name-14520">{{ user.name }}</span>
                            <span v-bind:style="StyleColor" class="float-right online-offline indicator"></span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>

        <div v-if="search != true">

                <ul class="list-group scroll-y ">
                    <li v-for="user in users_for_chat" class="list-group-item pointer hover" :key="user.u_id" v-on:click="event_friend_id(user)">
                        <div class="row style-margin"  >
                            <div class="style-image-div-1250"><img class="style-image-1250" :src="user.u_profile_pic"  />
                                <span class="name-14520">{{ user.u_name }}</span>
                                <span v-if="user.is_Online != true" v-bind:style="StyleColor_red" class="float-right online-offline indicator"></span>
                                <span v-else v-bind:style="StyleColor_green" class="float-right online-offline indicator"></span>
                            </div>
                        </div>
                    </li>
                </ul>

        </div>

    </div>
</template>

<script>

    export default {
        name: "left_sidebar",
        data: function(){
            return {
                search_friends: '',
                errors: [],
                users_for_chat:[],
                StyleColor_green : ' background-color: green;',
                StyleColor_red : ' background-color: red;',
                chat_user : [],
                search : false,
                users_search_result : [],


            }
        },
        props : ['chat_user_prop'],
        watch: {
            search_friends : function(after, before) {
                this.search =  true;
                return   this.get_search_friends();
            },
            chat_user : function(after, before) {
                return  this.chat_user;
            },
            conversation_id : function(after, before) {
                return  this.conversation_id;
            },
            chat_user_prop : function(after, before) {
               return  this.chat_user = this.chat_user_prop;
            },
        },
        // directives: {
        //     debounce
        // },
        methods:{
            event_search_friend_id : function ($user) {
                this.chat_user = $user;
                this.$emit('change_User',this.chat_user);
                this.search_friends = '';
                this.user_select_search_result();

            },
            user_select_search_result : function () {
                axios.post(`/user_select_search_result`,{
                    selected_friend : this.chat_user.id,
                }).then(response => {
                    this.conversation_id = response.data.conversation_id;

                })
                this.user_select_to_chat();
            },

            event_friend_id : function ($user) {
                this.chat_user = $user;
                // console.log(this.chat_user );
                this.$emit('change_User',this.chat_user);
                this.search_friends = '';
            },
            get_search_friends: function () {
                if(this.search_friends != ''){
                    axios.post(`/get_search_friends`,{
                        search_word: this.search_friends,
                    }).then(response => {
                        this.users_search_result = response.data;
                        //console.log(response.data);
                        //
                    })
                }else{
                    this.search_friends = '';
                    this.search = false;
                }
            },
            user_select_to_chat : function () {
                axios.post(`/user_select_to_chat`).then(response => {
                    this.users_for_chat = response.data;
                     this.$emit('change_User',this.users_for_chat[0]);
                })
            },

        },

        created(){
            this.user_select_to_chat();

        },
    }
</script>

<style scoped>
    ul.list-group.scroll-y{
        overflow-y: scroll;
        position: absolute;
        width: 91%;
        height: 84%;
    }
    li.list-group-item.pointer.hover:hover {
        background-color: #dddfe2;
    }
    li.list-group-item.pointer.hover {
        background-color: #f1f1f1c2;
        height: 50px;
    }
    span.float-right.online-offline.indicator {
        height: 9px;
        width: 9px;
        right: 11px;
        border-radius: 100%;
        position: absolute;
        margin-top: calc(-22px);
    }
    img.style-image-1250 {
        height: 34px;
        width: 34px;
        border-radius: 100%;
    }
    span.name-14520 {
        font-size: 12px;
        padding-left: 2px;
        font-family: sans-serif;
        font-weight: lighter;
    }
    li.list-group-item.pointer {
        cursor: pointer;
    }
    .scroll-y::-webkit-scrollbar {
        width: 6px;
    }

    .scroll-y::-webkit-scrollbar-track {
        -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
        border-radius: 10px;
    }

    .scroll-y::-webkit-scrollbar-thumb {
        border-radius: 10px;
        -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5);
    }
</style>