<template>
    <div>
        <div class="nav-item dropdown btn-sm" id="notification-dropdown">
            <li id="dLabel" data-toggle="dropdown" data-target="#">
                <i class="fa fa-bell" aria-hidden="true"></i>
                <span v-if="notification_data_count > 0" class="badge badge-info">{{ notification_data_count }}</span>
            </li>

            <div class="dropdown-menu notifications dropdown-menu-right" role="menu" aria-labelledby="dLabel">

                <div class="notification-heading "><h4 class="menu-title">Notifications</h4><h4 @click="viewall()" class="menu-title float-right">View all<i class="fas fa-arrow-alt-circle-right"></i></h4>
                </div>
                <li class="divider"></li>
                <div class="notifications-wrapper ">
                    <a class="content " v-for="notification in notification_data">
                        <div class="notification-item" @click="goto_destination(notification.data.username)" >
                            <div class="row">
                                <div class="col-1"> <img class="" width="48px" height="48px" style="border-radius: 100%" :src="notification.data.profile_pic" /></div>
                                <div class="col-11">  <p class="item-info pt-1 pl-4">

                                   <span class="text-capitalize font-weight-bold">{{ notification.data.name }}</span>
                                    {{ notification.data.message }}


                                </p></div>



                            </div>


                        </div>

                    </a>
                    <a class="content" v-if="notification_data.length === 0">
                        <div class="notification-item ">
                            <h4 class="item-title">No Message to display</h4>
                        </div>

                    </a>

                </div>
                <li class="divider"></li>
                <div class="notification-footer"><h4 @click="viewall()" class="menu-title">
                    View all
                    <i class="fas fa-arrow-alt-circle-right"></i></h4></div>
            </div>

        </div>
    </div>


</template>

<script>
    import { bus } from '../../app.js';

    export default {
        name: "header_notification_component",
        mounted : function () {
            this.listen();
        },
        props : [
            'user_id',
            'user'
        ],
        watch: {
            notification_data: function () {
                return this.notification_data;
            } ,
            notification_data_count: function () {
                return this.notification_data_count;
            } ,
            get_notification: function () {
                return this.get_notification();
            }
        },
        data: function() {
            return {
                notification_data: [],
                notification_data_count: 0,
                base_url : '',
                username : '',
            }
        },
        created : function () {
          this.base_url =  process.env.MIX_VUE_BASE_URL;
          this.get_notification();
          this.username  = this.user.username;
            bus.$on('new_message_event_to_header', obj => {
                this.get_notification();
            });
        },
        methods: {
            goto_destination : function($url) {
                window.location.href = this.base_url + $url;
            },
            viewall : function () {
                window.location.href =  this.base_url + this.username + '/notifications';
            },
            get_notification : function () {
                  this.notification_data = [];
                this.notification_data_count = 0;
                axios.post(this.base_url + 'get_Notification', {
                    user_id: this.user_id,
                }).then(response=>{
                    this.notification_data = this.notification_data.concat(response.data.notification);
                    this.notification_data_count = response.data.count;

                });
            },
            mark_as_read_Notification : function () {
                axios.post('get_Notification', {
                    user_id: this.user_id,
                }).then(response=>{
                    console.log(response.data);
                });
            },
            listen : function(){
               // Pusher.logToConsole = true;
                Echo.private('App.User.'+this.user_id)
                    .notification((notification) => {
                        if(notification.type_of == 'send_friend_request'){
                             this.get_notification();
                          //   this.notification_data_count++;
                            this.$toaster.success('You got a new friend request from '+ notification.name, {timeout: 3000});

                        }else if(notification.type_of == 'accept_friend_request'){
                             this.get_notification();
                          //  this.notification_data_count++;
                            this.$toaster.success(notification.name+' accept your friend request', {timeout: 3000});

                        }
                    });
                // var pusher = new Pusher(process.env.MIX_PUSHER_APP_KEY, {
                //     cluster: process.env.MIX_PUSHER_APP_CLUSTER,
                //     encrypted: true
                // });
                // var channel = pusher.subscribe('my-channel');
                // channel.bind('my-event', function(data) {
                //     console.log(data);
                // });
            }
        }
    }
</script>

<style scoped>
    span.badge.badge-info {
        margin-left: -8px;
    }

    .dropdown {
        display:inline-block;
        padding:10px;
    }



    .notifications {
        min-width:420px;
        //height: auto;
    }

    .notifications-wrapper {
        overflow:auto;
        max-height:450px;
        height: auto;
    }

    .menu-title {
        color: #ff74c2;
        font-size:0.9rem;
        display:inline-block;
    }

    .arrow-alt-circle-right {
        margin-left:10px;
    }


    .notification-heading, .notification-footer  {
        padding:2px 10px;
    }


    .dropdown-menu.divider {
        margin:5px 0;
    }

    .item-title {

        font-size:0.9rem;
        color:#000;

    }

    .notifications a.content {
        text-decoration:none;
        background:#ccc;

    }

    .notification-item {
        padding:10px;
        margin:5px;
        background-color: #ece9e947;
        border-radius:4px;
        border: 1px solid #a0a099;
    }
    li#dLabel:hover {
        cursor: pointer;
    }
    h4.menu-title.float-right,h4.menu-title {
        cursor: pointer;
    }



</style>