<template>
    <li class="mr-2">
        <form class="form-inline"  v-on:submit.prevent>
            <div v-bind:style="input_width"  class="input-group input-group-sm dropdown show" >
                <span class="input-group-addon"> <button type="button" class=" btn "><i class="fas fa-search"></i></button></span>
                <transition name="slide-fade">
                <input   v-on:click='click' v-on:keyup.enter="press_enter()" v-model.lazy="search_input" v-debounce="500" class="form-control dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" type="search" placeholder="Search any thing" aria-label="Search">
                </transition>
               <div  v-show="computedvalue" >
                   <div class="dropdown-menu" style="width: 400px;"  aria-labelledby="dropdownMenuButton">
                       <div class="dropdown-item pt-1 pb-2 my-style-div-1203"  v-for="result in search_result" :key="result.id" >

                           <div class="row" style="cursor: pointer;">
                               <div class="col-2">
                                    <img :src="result.profile_pic" width="45px" height="45px" style="border-radius: 100%" />
                               </div>
                               <div class="col-10 pt-2">
                                    <a :href="base_url + result.username" class="" style="color: black;">{{result.name}}</a>
                               </div>
                           </div>
                       </div>
                       <div class="dropdown-item pt-1 pb-2 h-25" @click="gotosearchpage()" style="background-color: #ffe418; margin-bottom: -8px;cursor: pointer;">See all result</div>
                   </div>
               </div>

            </div>


        </form>
    </li>
</template>


<script>
    export default {
        name: "header-search-component",
        props:[
            'user_id'
        ],
        data : function () {
            return{
                search_input : null,
                search_result : [],
                base_url : '',
                input_width : 'width: 200px;',
            }
        },
        created : function() {
            this.base_url =  process.env.MIX_VUE_BASE_URL;
        },
        watch : {
            search_input : function () {
               return  this.search_input_post();
            },
            computedvalue : function () {
               return  this.computedvalue;
            },
            search_result : function () {
                console.log(this.search_result.length );
               return  this.search_result;
            },
            input_width : function () {
                return this.input_width;
            },
            click : function () {
                return this.click();
            }

        },
        computed : {
            computedvalue : function () {
                return this.search_result.length > 0 ;
            } ,
        },
        // computed: {
        //     results() {
        //         return this.keywords ? this.posts.filter(result => result.title.includes(this.keywords)) : [];
        //     }
        // },
        methods :  {
            // highlight: function(text) {
            //     return text.replace(new RegExp(this.keywords, 'gi'), '<span class="highlighted">$&</span>');
            // },
            press_enter : function (event) {

            },
            gotosearchpage : function() {
                window.location.href = this.base_url + 'all-result/'+this.search_input+'/'+this.user_id;
            },
            click : function() {

                this.input_width = 'width: 400px;';
            },
            search_input_post : function() {
                if(this.search_input != '') {
                    axios.post(this.base_url + 'header_search', {
                        search_input_ajax: this.search_input,
                        auth_id: this.user_id,
                    }).then(response => {
                        // console.log(response.data);
                        this.search_result = response.data;
                    }).catch(error => {
                        console.log(error);
                    });
                }else{
                    this.search_result = [];
                }
            },

        }
    }
</script>

<style scoped>
    .highlighted { color: red }
    .dropdown-item.pt-1.pb-2.my-style-div-1203 {
        border-bottom: 1px solid #007bff;
        padding-top: 7px;
        margin-top: 2px;
    }
</style>