<template>
    <div>
        <li class=" nav-item dropdown dropleft dropdown-notifications ">
            <a class=" nav-link btn-sm"  id="notofication" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="far fa-envelope"></i><span v-if="" class="badge badge-pill badge-danger"></span>
            </a>

<div class="fffffffwqwq">  <div class="dropdown-menu" style="width: 335px" id="notification-dropdown" >
    <div class="ghtjy">
        <div class="">
            <div class="dropdown-header text-center" style="cursor: pointer;" >
                <a id="dvbnzaqmkl" :href="base_url + 'messenger'">View in Messenger</a>
            </div>
        </div>
        <div class="dropdown-divider">

        </div>
        <div v-for="conversation in conversation_lists" @click="gotoMessanger(conversation.c_id)" class="dropdown-item">
            <div style="border: 0.5px solid #484848;border-radius:10px;" class="row  pt-1 pb-1">
                <div class="col-1">
                    <img class="ssdbngk" width="45px" style="border-radius: 100%" height="45px" :src="conversation.u_profile_pic" />
                </div>
                <div class="col-9 ml-4 ">

                   <a id="wwerbnmj" class="pt-1" :href=" conversation.u_username ">{{ conversation.u_name }}</a>

                    <br />

                    <span v-for="mess in conversation.message1 ">
                                    <span id="nmbftioldfvcxz">{{ mess.m_body | truncate(25)}} </span>
                                        <span class="">
                                         <span class="badge badge-pill"> {{mess.m_created_at | time_filter }}
                                        </span>
                                    </span>

                                <span v-if="conversation.message1 == ''"></span>
                    </span>


                </div>

            </div>
        </div>
        <div class="dropdown-item" v-if="this.conversation_lists.length === 0">No conversation yet</div>
        <div class="dropdown-header">

        </div>
    </div>



</div>

</div>



        </li>
    </div>
</template>

<script>
    import { bus } from '../../app.js';
    export default {
        name: "headerMessage",
        data: function () {
            return {
                conversation_lists : [],
                base_url : '',
            }
        },
         methods : {
             header_Conversation_list_with_one_messages : function () {
                 axios.post(this.base_url+'header_Conversation_list_with_one_messages/').then(response =>  {
                         this.conversation_lists = response.data ;
                 }).catch(error => {
                     // this.flash('unable to update post', 'error');
                 });
             },
             gotoMessanger : function ($c_id) {
                 axios.post(this.base_url+'gotoMessenger/',{
                     c_id : $c_id
                 }).then(response =>  {
                      window.location.href = this.base_url + 'messenger/';
                 });
             }
         },
        created : function () {
            this.base_url =  process.env.MIX_VUE_BASE_URL;
            this.header_Conversation_list_with_one_messages();
            bus.$on('new_message_event_to_header', obj => {
                this.header_Conversation_list_with_one_messages();
            });
        }
    }
</script>

<style scoped>
    .ghtjy {
        max-height: 250px;
        overflow-y: hidden;
    }
    .ghtjy:hover {
        overflow: auto;
    }
    .fffffffwqwq {
        margin-left: -87px;
        position: absolute;
        margin-top: 9px;
    }
    .dropdown-header.text-center {
        font-size: 12px;
        height: 20px;
        margin-top: -8px;
        font-family: serif;
    }
    a#wwerbnmj {
        font-family: serif;
        font-size: 15px;
        font-weight: lighter;
        color: #000;
    }
    span#nmbftioldfvcxz {
        font-family: monospace;
        font-size: 14px;
    }
    .dropdown-item {
        cursor: pointer;
    }
</style>