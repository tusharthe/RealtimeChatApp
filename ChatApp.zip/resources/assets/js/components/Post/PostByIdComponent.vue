<template>
    <div>

        <post v-for="(post, index) in result "
              v-bind:post="post.id"
              v-bind:index="index"
              v-bind:key="post.id"
              :profile_pic="post.user.profile_pic"
              :name="post.user.name"
              :images="post.images"
              :username="post.user.username"
              :updated_at="post.updated_at"
              :post_content="post.content"
              :post_user_id="post.user_id"
              :post_id="post.id"
              :likes="post.likes[0]"
              :comments="post.comments"
              :auth_user="auth_id"
              :videoId="post.youtube_link"
        ></post>
    </div>
</template>

<script>
     var moment = require('moment');
    import post from './PostComponent'
    export default {
        name: "post-by-id",
        props: [
            'result',
            'auth_id'
        ],
        components : {
            post
        },
    }
</script>

<style scoped>

</style>