<template>
    <div>
        <br />
        <flash-message class="myCustomClass"></flash-message>
        <br />
        <div class="card">
            <div class="card-header">
                <div class="row card-title">
                    <div class="card-img col-1"><img :src="post.user.profile_pic" style="width: 45px;height: 45px;border-radius: 100%"/></div>
                    <div class="card-title col-10"><a href="">{{post.user.name}}</a>&nbsp;<div class="card-subtitle">{{post.created_at | time_filter}}</div></div>
                    <div id="post-side-icon " class="dropdown float-right col-1">
                        <span class=""  aria-haspopup="true" data-toggle="dropdown"><i class="fas fa-ellipsis-v"></i></span>
                        <div id="post-dropdown" class="dropdown-menu">
                            <a class="dropdown-item">setting</a>
                            <!--<a @click="editpost(post_id)" class="dropdown-item">edit</a>-->
                            <a class="dropdown-item" click="">delete</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="card-text">
                        <textarea class="form-control" v-model="post_text" rows="2" >{{post.content}}</textarea>

                    <div class="pt-4 pb-3" v-for="post_image in post_images" >
                        <img width="auto" height="500px"  class="img-fluid img" :src="base_url + 'photos/postImages/' +post_image"/>
                    </div>

                    <div class="float-right pt-2">
                        <button class="btn btn-sm btn-outline-warning" @click="cancle_update()" >cancel </button>
                        <button class="btn btn-sm btn-outline-success" @click="post_update()" >update </button>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-light">
                <div class="row">
                    <div class="col-6 text-center " id="like-section">   <span class="post-likes" @click="clickonlikebutton()">
                              <span v-if="count_like != 0">{{ count_like }}</span>
                              <span v-bind:hidden="is_auth_liked"> <i class="far fa-thumbs-up"></i></span>
                              <span v-bind:hidden="!is_auth_liked"><i class="fas fa-thumbs-up"></i></span>
                             </span></div>

                    <div class="col-6 text-center " id="">
                        <div class="comment-header-text" style="cursor: pointer;color: #007bff;" v-scroll-to="'.element, 50px'" >Comments ({{post_comments.length}})</div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-12 " v-if="open">
                        <div  id="comment-section">
                            <div class="text-center" id="no-comment-yet" v-if="post_comments == '' ">
                                <span class="text-center" >no Comment yet</span>
                            </div>
                            <div v-else>
                                <singlecomment v-for="comment in post_comments" :key="comment.id"
                                               :body="comment.body"
                                               :comment_id="comment.id"
                                               :created_at="comment.created_at"
                                               :post_id="comment.post_id"
                                               :user="comment.user"
                                               :auth_user_id="auth_id"
                                ></singlecomment>
                            </div>
                            <div class="comment-textbox col-12">
                                <form>
                                    <div class="row">
                                        <textarea  v-model="comment_text" class="form-control mt-0 pb-2 element" rows="1" placeholder="type your comment..."></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="float-right mt-2 pb-1">
                                            <button type="reset" @click="cancle_comment()"  class="btn btn-sm btn-outline-danger">cancel</button>
                                            <button type="button" @click="submit_comment()" class="btn btn-sm btn-outline-success">submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</template>

<script>
    var moment = require('moment');
    import singlecomment from './SingleCommentComponent.vue'
    export default {
        name: "edit-post-component",
        props:[
            'result',
            'auth_id'
        ],
        data : function () {
            return{
                post : [],
                count_like : 0,
                is_auth_liked : false,
                this_like : true,
                open : true,
                post_comments : [],
                post_likes : [],
                comment_text : '',
                base_url : '',
                post_text : '',
                post_images : ''
            }
        },
        components:{
            singlecomment
        },
        mounted : function() {
            this.likes_count_fun(this.post_likes);
        },
        methods: {

            post_update : function () {
                axios.post(this.base_url+'update_post/',{
                    id : this.post.id,
                    post_text: this.post_text,
                    auth_id :  this.auth_id,
                }).then(response =>  {
                    console.log(response.data);
                    if(response.data == 'success'){
                        this.post.content = this.post_text ;
                        this.flash('Post was Success updated.', 'success',{timeout: 5000});
                    }
                }).catch(error => {
                    this.flash('unable to update post', 'error');
                });
            },
            cancle_update : function () {
                this.post_text  = this.post.content ;
            },
            CommentSection : function () {
                var container = this.$el.querySelector("#comment-text-area");
                container.scrollTop = container.scrollHeight;
            },
            clickonlikebutton: function () {
                axios.post(this.base_url+'SaveNewLike/',{
                    id : this.post.id,
                    auth_user : this.auth_id,
                }).then(response =>  {
                    if(response.data.success == 'success'){
                        if(response.data.liked == 'like'){
                            console.log('like');
                            this.count_like += 1;
                            this.is_auth_liked = true;
                        }else{
                            console.log('unlike');
                            this.count_like -= 1;
                            this.is_auth_liked = false;
                        }
                    }
                });
            },
            cancle_comment : function () {
                this.comment_text   = '';
            },
            likes_count_fun : function(value){
                if (!value) return '';
                var obj = {};
                obj = JSON.parse(value.user_id);
                var total = Object.keys(obj).length;
                if(total === 0) return '';
                this.count_like =  total;
                var auth = this.auth_id;
                var ttt = this.is_auth_liked;
                obj.forEach(function(element) {
                    if(element.user_id == auth) {
                        ttt  = true;
                    }
                });
                this.is_auth_liked = ttt;
            },
            submit_comment : function () {
                if(this.comment_text != '')
                    axios.post(this.base_url+'savecomment',{
                        user_id : this.auth_id,
                        post_id : this.post.id,
                        comment_text : this.comment_text,
                    }).then(response => {
                        if(response.data.success == 'true'){
                            this.comment_text = '';
                            this.post_comments = this.post_comments.concat(response.data.new_comment);
                        }
                    });

            }
        },
        filters : {
         time_filter :function (value) {
             return  moment(value).fromNow();
         } ,
        },
        created: function () {
          this.base_url =  process.env.MIX_VUE_BASE_URL;
          this.post = this.result;
          this.post_text = this.post.content;
          this.post_comments = this.post.comments;
          this.post_images = JSON.parse(this.post.images);
          this.post_likes = this.post.likes[0];
        },

    }
</script>

<style scoped>
    span.post-likes {
        font-size: 15px;
        color: #007bff;
        margin-left: 7px;
        cursor: pointer;
    }
    div#like-section {
        border-right: 2px solid #007bff;
    }
</style>