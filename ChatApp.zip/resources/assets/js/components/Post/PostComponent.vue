<template>
    <div>
        <div id="post-new-post" class="list__item"  >
            <div class="mt-2 mb-2 pt-2 pb-2">
                <div class="card bg-light">
                    <div class="card-header bg-light">
                        <div class=" row">
                            <div class="card-img col-1">
                                <img :src="profile_pic" class="img"  width="50px" height="50px" style="border-radius: 100%;" />
                            </div>
                           <div class="card-title col-10">
                               <a id="user-by-post" :href="username"> {{ name }}  </a>
                               <div class="card-subtitle"> {{updated_at | time_filter}} </div>
                           </div>

                            <div id="post-side-icon " v-if="auth_user == post_user_id" class="dropdown float-right col-1">
                                <span class=""  aria-haspopup="true" data-toggle="dropdown"><i class="fas fa-ellipsis-v"></i></span>
                                <div id="post-dropdown" class="dropdown-menu">
                                    <a class="dropdown-item">setting</a>
                                    <a @click="editpost(post_id)" class="dropdown-item">edit</a>
                                    <a class="dropdown-item" @click="deletePost(post_id)">delete</a>

                                </div>
                            </div>
                        </div>



                    </div>
                    <div class="card-body" id="post-title">
                        <div class="card-text">

                            {{post_content}} <br /> <br />
                            <div v-if="post_videoId != ''">
                                <youtube  player-width="100%"  :video-id="post_videoId"></youtube>
                            </div>


                        </div>

                        <div v-if="images != null">
                           <div class="text-center" v-for="post_image in post_images">
            <!--http://127.0.0.1:8000/photos/postImages/post_img_5aac0a0e93250b7d91cdd9a49e5d82bda2e3a0bdf001d.jpg-->
                               <img style="display:block;"  class="img-fluid" :src="'photos/postImages/'+post_image" width="100%" height="auto"/>
                           </div>

                        </div>

                    </div>
                    <div class="card-footer bg-light">
                        <div class="row">
                            <div class="col-6 text-center " id="like-section">   <span class="post-likes" @click="clickonlikebutton(post_id)">
                              <span v-if="count_like != 0">{{ count_like }}</span>
                              <span v-bind:hidden="is_auth_liked"> <i class="far fa-thumbs-up"></i></span>
                              <span v-bind:hidden="!is_auth_liked"><i class="fas fa-thumbs-up"></i></span>
                             </span></div>

                            <div class="col-6 text-center " id="comment-section">
                                <div class="comment-header-text" style="cursor: pointer" @click="openCommentSection()"  >Comments ({{comments.length}})</div>
                            </div>
                        </div>
                        <div class="row">
                             <comment :open="open" :post_id="post_id" :auth_user="auth_user" :post_comments="post_comments"></comment>
                        </div>

                    </div>


                </div>
            </div>

        </div>
    </div>
</template>

<script>
    // var moment = require('moment');
     import comment from '../UserProfile/PostCommentComponent.vue'
    export default {
        name: "post",
        components: {
            comment,
        },
        props: [
            'profile_pic',
            'name',
            'updated_at',
            'post_content',
            'post_user_id',
            'post_id',
            'username',
            'auth_user',
            'likes',
            'comments',
            'images',
            'videoId',
        ],
        data: function() {
            return{
                count_like : 0,
                is_auth_liked : false,
                this_like : true,
                open : true,
                post_comments : [],
                post_images : [],
                post_videoId : '',
                base_url : ''
            }
        },
        mounted : function() {
          this.likes_count_fun(this.likes);
            },
        watch:{
            count_like : function(after, before) {
                return this.count_like;
            },
            this_like : function(after, before) {
                return this.this_like;
            },
            open : function(after, before) {
                return this.open;
            },
            is_auth_liked : function() {
                return this.is_auth_liked;
                },
            likes_count_fun : function() {
                return this.likes_count_fun;
                },
            comments : function () {
                return this.comments;
            }

        },
        created: function()  {
            this.base_url =  process.env.MIX_VUE_BASE_URL;
            this.post_comments =  this.comments;
            this.post_images = JSON.parse(this.images);
             this.getyouTubeID();
            // this.post_videoId = this.$youtube.getIdFromURL("https://www.youtube.com/watch?v=pz95u3UVpaM&list=PLx0sYbCqOb8TBPRdmBHs5Iftvv9TPboYG");
        },
        methods:{
            getyouTubeID : function () {
                if(this.videoId != null && this.videoId != 'null'){
                    var ID = JSON.parse(this.videoId);
                    this.post_videoId = ID[0];
                }
            },
            deletePost : function () {
                axios.post('/deletePost',{
                    post_user_id: this.post_user_id,
                    post_id: this.post_id,
                }).then(response =>  {
                    console.log(response.data);
                });
            },
            editpost: function ($id) {
                window.location.href = "/post/"+$id+"/edit";
            },
            openCommentSection : function () {
              this.open = !this.open;
            },
            likes_count_fun : function(value){
                if (!value) return '';
                var obj = {};
                obj = JSON.parse(value.user_id);
                var total = Object.keys(obj).length;
                if(total === 0) return '';
                this.count_like =  total;
                var auth = this.auth_user;
                var ttt = this.is_auth_liked;
                obj.forEach(function(element) {
                    if(element.user_id == auth) {
                        ttt  = true;
                    }
                });
                 this.is_auth_liked = ttt;
            },
            clickonlikebutton: function ($id) {
                axios.post('/SaveNewLike',{
                    id : $id,
                    auth_user : this.auth_user,
                }).then(response =>  {
                    if(response.data.success == 'success'){
                        if(response.data.liked == 'like'){

                            this.count_like += 1;
                            this.is_auth_liked = true;
                        }else{

                            this.count_like -= 1;
                            this.is_auth_liked = false;
                        }
                    }
                });
            },
        }
    }
</script>

<style scoped>
    img.preview {
        width: 200px;
        background-color: white;
        border: 1px solid #DDD;
        padding: 5px;
    }
    .file-upload-post {
        width: auto;
        border: 1px solid #7b7979;
        border-radius: 20px;
        background: #eae4e478;
    }
    .is-collapsed {
        display: none;
    }
    .vue-content-placeholders-text {
        margin-left: 72px;
        width: 85%;
    }
    div#card-header {
        height: 38px;
        margin-top: -9px;
    }
    .post-placeholders {
        margin: 5px 0 0 19px;
    }
    button.post-submit-button {

        border: 1px solid black;
        color: #000000;
        font-family: monospace;
        font-size: 14px;
    }
    button.post-reset-button {

        border: 1px solid black;
        color: #000000;
        font-family: monospace;
        font-size: 14px;
    }
    button.post-type-button {

        border: 1px solid black;
        color: #000000;
        font-family: monospace;
        font-size: 14px;
    }
    .comment-header-text {
        color: #007bff;
    }
    .button-class {
        margin-top: 8px;
        background-color: #ffffff;
        height: 45px;
        width: 100%;
    }
    div#post-side-icon {
        margin-top: 0px;
    }
    textarea#post-textarea {
    //  position: relative;
        float: right;
        border-radius: 0%;
        border: none;
        width: 92%;
        resize: none;
    }
    textarea#post-textarea:focus {
        outline: none;
    }
    div#post-dropdown {
        margin-left: 30px;
        min-width: 77px;
        background-color: #dbdbe2;
        font-size: 14px;
        font-family: serif;
    }
    span.post-likes {
        font-size: 15px;
        color: #007bff;
        margin-left: 7px;
        cursor: pointer;
    }
    div#like-section {
        border-right: 2px solid #007bff;
    }


</style>