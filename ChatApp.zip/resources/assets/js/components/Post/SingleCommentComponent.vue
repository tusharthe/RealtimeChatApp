<template>
    <div class="row comment-section-row">
        <div class="col-1 comment-user-image">
            <img :src="user.profile_pic" width="45px" height="45px" style="border-radius: 100%"  />
        </div>
        <div class="col-11 comment-body">
            <div>
                <span class="comment-body-text"> {{body }} </span>
                <br/>
                <span class="comment-by">by</span>
                <span class="comment-user-name"><a :href="this.base_url + user.username" >{{ user.name }}</a></span>
                <span class="comment-timing">at {{ created_at | time_filter }}</span>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "singlecomment",
        props: [
            'body',
            'comment_id',
            'created_at',
            'post_id',
            'user',
            'auth_user_id',
        ],
        filters: {
            time_filter:function (value) {
                return moment(value).fromNow();
            },
        },
        created: function()  {
            this.base_url =  process.env.MIX_VUE_BASE_URL;
        },
    }
</script>

<style scoped>
    .row.comment-section-row {
        width: 100%;
        padding: 2px 0 0px 0px;
        margin: 6px 0px 11px -2px;
        word-break: break-word;
        word-spacing: normal;
        /*height: 78px;*/
        /* position: absolute; */
        /* display: block; */
        /* max-height: 0; */
        border-radius: 7px;
        border: 1px solid #007bff33;
        background-color: white;
    }
    apan.comment-body-text {
        word-break: break-word;
        font-family: sans-serif;
        font-size: 14px;
        text-align: center;
        background-color: #f5f8fa;
    }
    apan.comment-user-name {
        font-size: 12px;
        font-family: monospace;
        background-color: #f5f8fa;
    }
    .col-11.comment-body {
        margin-left: 0px;
    }
    span.comment-by {
        font-weight: 100;
        background-color: #f5f8fa;
    }
    span.comment-timing {
        font-size: 11px;
        padding-left: 6px;
        color: #410d0d;
        background-color: #f5f8fa;
    }
</style>