<template>
    <div class="mt-4">
        <vue-snotify></vue-snotify>
        <div class="row">
            <div class="card" style="width: 100%">
                <div class="card-header ">
                  <span>Notifications</span>
                    <span class="float-right mr-0 badge-pill badge badge-warning" @click="markallasread()" style="cursor: pointer" id="ddvddsss">Mark all as Read</span>
                    <span class="float-right mr-2 badge-pill badge badge-info" @click="deleteallnotification()" style="cursor: pointer" id="ddvddss">Delete All</span>
                </div>
                <div class="card-body ">
                    <div v-for="notification in notifications" :id="notification.id" class="fhfyrt card-text svbnf">

                    <div >
                        <notification v-on:delete_notification="delete_notification($event)" :notification="notification" ></notification>

                    </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import  notification from './NotificationComponent.vue'
    import Vue from 'vue';
    export default {
        name: "notification-page-component",
        props : [
            'user'
        ],
        components : {
            notification
        },
        data : function () {
            return {
                notifications : [],
                base_url : '',
                view : 'View'

            }
        },
        methods : {
            delete_notification : function ($event) {
                Vue.nextTick()
                    .then(function () {
                        $('#'+$event).hide();
                    })
            },
            Authuserallnotification : function () {
                axios.post('/Authuserallnotification').then(response=> {
                    this.notifications = response.data;
                });
            },
            markallasread : function () {
                axios.post('/markallasreadnotification').then(response=> {
                   if(response.data = 'success'){
                       // this.$notify.success('This is success message');
                       this.$snotify.success('All are Marked as read', {timeout: 2000,showProgressBar: false,});
                       this.Authuserallnotification();
                   }
                });
            },
            deleteallnotification : function () {
                axios.post('/deleteallnotification').then(response=> {
                   if(response.data = 'success'){
                       // this.$notify.success('This is success message');
                       this.$snotify.success('Only read notification are deleted','Deleted Successfully', {timeout: 5000,showProgressBar: false,  position: 'leftTop'});
                       this.Authuserallnotification();
                   }
                });
            },
        },
        created : function () {
            this.base_url =  process.env.MIX_VUE_BASE_URL;
            this.Authuserallnotification();
        }
    }
</script>

<style scoped>
    .fhfyrt.card-text.svbnf {
        background-color: #eae0e052;
        margin-top: 5px;
        margin-bottom: 14px;
        padding: 7px 6px 7px 25px;
        border: 1px solid skyblue;
        border-radius: 27px;
    }
    a#jfhfbj {
        font-size: 14px;
        text-decoration: none;
        font-family: serif;
    }

    .card-body {
        width: 100%;
        max-height: 520px;
        overflow-y: scroll;
    }

    /*.pl-2.njmhkljotuhn.mt-1 {*/
        /*word-break: break-all;*/
        /*position: fixed;*/
    /*}*/
    .ghtyumnj {
        cursor: pointer;
    }
</style>
<style>
    body{
     overflow-y: hidden;
    }
</style>