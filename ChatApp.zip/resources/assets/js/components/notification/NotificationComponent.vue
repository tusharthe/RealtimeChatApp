<template>
    <div class="row" >

        <div class="col-1">
            <div>
                <img id="dhbngkti" :src="notification.data.profile_pic" style="width:45px;height: 45px;border-radius: 100%" class="card-img">
            </div>
        </div>
        <div class="pl-2 njmhkljotuhn mt-1 col-11">
            <div>
                <a id="jfhfbj" :href="base_url + notification.data.username">{{notification.data.name}} </a> {{notification.data.message}}
                <span class="float-right dfbgnr-yuuh pr-4">
                                        <span @click="deletenotification()" class="badge-pill badge badge-danger ghtyumnj"> <a>Delete</a>
                                        </span>
                                        <span @click="markasread()" class="badge-pill badge badge-danger ghtyumnj"> <a>Mark as read</a>
                                        </span>
                                        <span class="badge-pill badge badge-danger ghtyumnj"> <a>View</a>
                                        </span>

                                    </span>
                <br />
                {{notification.data.time.date | time_filter}}





            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "notification-component",
        props : [
            'notification'
        ],
        data : function () {
          return {
              base_url : '',
              n_id : ''
          }
        },
        created : function () {
            this.base_url =  process.env.MIX_VUE_BASE_URL;
            this.n_id = this.notification.id;
        },
        methods : {
            markasread : function () {
                axios.post('/markasread',{ n_id : this.n_id}).then(response=> {
                    if(response.data = 'success'){
                        // this.$notify.success('This is success message');
                        this.$snotify.success('Marked as read Successfully', {timeout: 5000,showProgressBar: false,});

                    }
                });
            },
            goto_destination : function($url) {
                window.location.href = this.base_url + $url;
            },
            deletenotification : function () {
                axios.post('/deletenotification',{
                    n_id : this.n_id
                }).then(response=> {
                    if(response.data = 'success'){
                        this.$emit('delete_notification',this.n_id);
                        this.$snotify.success('Deleted Successfully', {timeout: 3000,showProgressBar: false,});
                    }
                });
            },

        }
    }
</script>

<style scoped>
    .fhfyrt.card-text.svbnf {
        background-color: #eae0e052;
        margin-top: 5px;
        margin-bottom: 14px;
        padding: 7px 6px 7px 25px;
        border: 1px solid skyblue;
        border-radius: 27px;
    }
    a#jfhfbj {
        font-size: 14px;
        text-decoration: none;
        font-family: serif;
    }

    .card-body {
        width: 100%;
        max-height: 520px;
        overflow-y: scroll;
    }
    .ghtyumnj {
        cursor: pointer;
    }
</style>