

require('./bootstrap');

window.Vue = require('vue');

import Toaster from 'v-toaster'
import 'v-toaster/dist/v-toaster.css'
import header_notification from './components/Header/HeaderNotificationComponent.vue'
import header_message from './components/Header/HeaderMessageComponent.vue'
import header_search from './components/Header/HeaderSearchComponent.vue'
import home_post from './components/Home/HomePostComponent.vue'
import home_left_side from './components/Home/HomeLeftSideComponent.vue'
import swtch from './components/UserProfile/SwitchComponents.vue'
import edit_profile from './components/UserProfile/EditProfileComponent.vue'
import home_side_chat from './components/Home/HomeSideChatComponent.vue'
import messenger_index from './components/Messenger/MessengerIndexComponent'
import edit_post from './components/Post/EditPostComponent'
import post_by_id from './components/Post/PostByIdComponent.vue'
import notification_page from './components/notification/NotificationPageComponent.vue'
import VueContentPlaceholders from 'vue-content-placeholders'
import VueChatScroll from 'vue-chat-scroll'
import vue2Dropzone from "vue2-dropzone"
import Snotify from 'vue-snotify';

import VueYouTubeEmbed from 'vue-youtube-embed'
import VTooltip from 'v-tooltip'


Vue.use(VTooltip)
Vue.use(Snotify)
Vue.use(VueYouTubeEmbed)
import VueFlashMessage from 'vue-flash-message';
Vue.use(VueFlashMessage);

Vue.use(VueChatScroll)

Vue.use(VueContentPlaceholders);

var VueAutosize = require('vue-autosize');

Vue.use(VueAutosize);
const csrfToken = $('meta[name="csrf-token"]').attr('content');

var fs = require('fs');

// optional set default imeout, the default is 10000 (10 seconds).
Vue.use(Toaster, {timeout: 5000});
import VueNoty from 'vuejs-noty'
import Delay from 'vue-delay'
Vue.use(Delay);
Vue.use(VueNoty);
var lodash = require('lodash');



var VueAutosize = require('vue-autosize');

Vue.use(VueAutosize);
import vueScrollTo from 'vue-scroll-to';

Vue.use(vueScrollTo);


import VueCroppie from 'vue-croppie';

Vue.use(VueCroppie);

window.moment = require('moment');
function debounce(fn, delay = 300) {
    var timeoutID = null;

    return function () {
        clearTimeout(timeoutID);

        var args = arguments;
        var that = this;

        timeoutID = setTimeout(function () {
            fn.apply(that, args);
        }, delay);
    }
};
// this is where we integrate the v-debounce directive!
// We can add it globally (like now) or locally!
Vue.directive('debounce', (el, binding) => {
    if (binding.value !== binding.oldValue) {
        // window.debounce is our global function what we defined at the very top!
        el.oninput = debounce(ev => {
            el.dispatchEvent(new Event('change'));
        }, parseInt(binding.value) || 300);
    }
});

Vue.filter('time_filter',function (value) {
    return  moment(value).fromNow();
});
var VueTruncate = require('vue-truncate-filter');
Vue.use(VueTruncate);



//jQuery TODO
Vue.nextTick()
    .then(function () {
        $('.dropdown-menu').click(function(e) {
            e.stopPropagation();
        });
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })
    });



// TODO
export const bus = new Vue();
const app = new Vue({
    el: '#app',
    components: {
        header_message: header_message,
        header_notification: header_notification,
        home_post: home_post,
		home_side_chat:home_side_chat,
        swtch: swtch,
        messenger_index : messenger_index,
        post_by_id : post_by_id,
        edit_post,
        header_search,
        notification_page,
        edit_profile,
        home_left_side,

    },
});








