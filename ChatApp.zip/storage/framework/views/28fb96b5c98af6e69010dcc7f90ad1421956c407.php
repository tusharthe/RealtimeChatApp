<?php $__env->startSection('page-title'); ?> SNS | Edit-Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="" class="container-fluid">
            <edit_profile auth_user="<?php echo e(Auth::id()); ?>  " details="<?php echo e($user); ?>"></edit_profile>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('meta'); ?>
    <script> window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?></script>
    <meta name="" content="">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>