<?php $__env->startSection('page-title'); ?>  SNS - Messenger <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <messenger_index auth_user_id="<?php echo e(Auth::User()->id); ?>"></messenger_index>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<style>

    body{
        overflow-y: hidden;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>