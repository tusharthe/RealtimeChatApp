<?php $__env->startSection('page-title'); ?>  SNS <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-content" class="container-fluid">
        <div  id="profile" >
            <?php if(Session::has('sendFriendRequestMassage')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                     <?php echo e(Session::get('sendFriendRequestMassage')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
          <swtch :loginuserid="<?php echo e(Auth::check() ?  Auth::user()->id : 0); ?>" :loginusercheck="<?php echo e(Auth::check() ?  'true' : 'false'); ?>"  loading_icon="<?php echo e(asset('svg/Spinx.svg')); ?>" ></swtch>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('style'); ?>
    <style>
        .nav-tabs {
            border-bottom: 2px solid #53d0d0;
        }

        /* tab color */
        .nav-tabs>li>a {
            background-color: #e8e9fe;
            color: #000;
            font-weight: 700;
            height: 52px;
            padding-top: 14px;
        }

        .nav-tabs .nav-link.active, .nav-tabs .nav-item.show .nav-link {
            color: #495057;
            background-color: #f5f8fa;
            border-color: #dee2e6 #dee2e6 #f5f8fa;
            border-bottom: 3px solid #000000;
        }

        /* active tab color */
        .nav-tabs>li.active>a, .nav-tabs>li.active>a:hover, .nav-tabs>li.active>a:focus {
            color: #fff;
            background-color: #e8e9fe;
            border-radius: 0%;
        }

        /* hover tab color */
        /*.nav-tabs>li>a:hover {*/
            /*border-color: #000000;*/
            /*background-color: #111111;*/
        /*}*/


        body{
            background-color: #e8e9fe;
            //overflow-y: hidden;
        }
        div#main-content {
            margin-top: 18px;
            width: 100%;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('meta'); ?>
    <script> window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?></script>
    <meta name="" content="">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>