<?php $__env->startSection('page-title'); ?>  SNS <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="left-side col-3">

            </div>
            <div class="middle-side col-7">
                <notification_page :user="<?php echo e(Auth::user()); ?>"></notification_page>
            </div>
            <div class="right-side col-3">

            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>