<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <style>
        body{
            background-color: #e7f1fa;
        }

        .card {
            height: 345px;
            background-color: #e7f1fa;
            border: 0px;
            margin-top: 126px;
        }
        .card-title {
            font-size: 33px;
            font-family: cursive;
            font-weight: 100;
        }
        a.btn.btn-12450 {
            background-color: #ffe418;
            font-size: 31px;
        }

        .thyoui-1250 {
            color: rgb(28, 116, 48);
            font-size: 40px;
            font-variant-caps: small-caps;
        }

    </style>
</head>
<body>
<div id="app">
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(config('app.name', 'Laravel')); ?>

            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">

                    <form class="form-row form-inline" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <input id="email" type="email" placeholder="your@email.com" title="email" tool class="mr-2 ml-2 form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                        <input id="password" type="password" placeholder="password" class=" mr-2 ml-2 form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                       <button type="submit" class="btn btn-primary">Login</button>
                    </form>

                </ul>
            </div>
        </div>
    </nav>
    <div class="container-fluid">
        <?php if($errors->has('email')): ?>
            <div class="alert mt-2 alert-danger fade show alert-dismissable" style="margin-bottom:22px">
                <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                <strong><?php echo e($errors->first('email')); ?></strong>
            </div>
        <?php endif; ?>


    </div>


    <main class="py-4">

        <div class="container">
            <div class="row">
                <div class="col-9 text-center">
                    <h1 class="thyoui-1250" style="color: #1c7430">Join The Largest Network</h1>
                    
                    <div>
                        <img src="<?php echo e(env('APP_URL').'photos/home/social-network.jpg'); ?>" height="478px" width="auto" />
                    </div>
                </div>

                <div class="col-3 text-center">
                    <div class="card">
                        <div class="card-title">
                            Not a member?<br />
                            Register Today<br/>
                        </div>
                        <div class="card-body">
                            <a href="register" class="btn btn-12450" >Register</a>
                        </div>
                    </div>



                </div>


            </div>

        </div>

    </main>
</div>

<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
